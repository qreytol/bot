from aiogram.utils.keyboard import InlineKeyboardBuilder, InlineKeyboardButton

def get_admin_keyboard(user_id: int):
    admin_keyboard = InlineKeyboardBuilder()
    admin_keyboard.row(InlineKeyboardButton(text='🧨 Спам', callback_data="spam"))
    admin_keyboard.row(InlineKeyboardButton(text='💬 Про сервіс', callback_data="info"))
    admin_keyboard.row(InlineKeyboardButton(text='☃️ Профіль', callback_data='profile'))
    admin_keyboard.row(InlineKeyboardButton(text='📨 Розсилка', callback_data='rozsilka'))
    admin_keyboard.row(InlineKeyboardButton(text='📱 Активні спами ', callback_data='active_spam'))
    admin_keyboard.row(InlineKeyboardButton(text='👤 Про користувача ', callback_data='about_user'))
    return admin_keyboard