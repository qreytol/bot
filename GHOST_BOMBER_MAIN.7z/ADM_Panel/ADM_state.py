from aiogram.fsm.state import State, StatesGroup

class vip_functional(StatesGroup):

    mailing_list = State()


class search_user_state(StatesGroup):

    user_search_id = State()
    user_type = State()
    user_balance = State()
    user_rank = State()


class mail_send(StatesGroup):

    text_send = State()