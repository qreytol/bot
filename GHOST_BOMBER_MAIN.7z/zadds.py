t = int(input())

def binpow(bs, n):
    if (n==0): return 1
    if (n%2): return bs*binpow(bs, n-1)
    k = binpow(bs, n/2)
    return k*k

while (t):
    t-=1
    a,b,c = map(int, input().split())
    d = f"{binpow(a,b)}"
    print(d)
    print(d[len(d)-c])