from aiogram.fsm.state import State, StatesGroup

class current_page_pos(StatesGroup):
    pos = State()