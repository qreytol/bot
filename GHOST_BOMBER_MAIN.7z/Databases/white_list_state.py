from aiogram.fsm.state import State, StatesGroup

class add_white_list_spam(StatesGroup):
    number = State()