from aiogram.fsm.state import State, StatesGroup


class information_for_spam(StatesGroup):
    phone = State()
    time = State()
    variable_spam = State()
