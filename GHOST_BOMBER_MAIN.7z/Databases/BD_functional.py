from motor.motor_asyncio import AsyncIOMotorClient
from datetime import datetime

class BD:
    def __init__(self):
        self.client = None
        self.db = None
        self.users_collection = None

    async def connect(self):
        # Підключення до MongoDB з налаштуваннями пулу з'єднань для оптимізації
        self.client = AsyncIOMotorClient(
            "mongodb://vzxaqNVwU7yonqHsdwJz:PwqifdH4sUmg9uBBc69E@93.113.25.38:27017/",
            minPoolSize=5, maxPoolSize=50
        )
        self.db = self.client["users_database"]
        self.users_collection = self.db["users"]

        # Індекси для часто використовуваних полів та їх комбінацій
        await self.users_collection.create_index("user_id", unique=True)
        await self.users_collection.create_index("interval")
        await self.users_collection.create_index("last_func")
        await self.users_collection.create_index("last_message_id")
        await self.users_collection.create_index([("user_id", 1), ("interval", 1)])
        await self.users_collection.create_index([("user_id", 1), ("last_message_id", 1)])
        await self.users_collection.create_index("white_list")

    async def close(self):
        # Закриття підключення до MongoDB
        if self.client:
            self.client.close()

    async def write_data(self, user_id: int, username: str, full_name: str, date: str):
        # Вставка нового користувача з усіма полями
        data = {
            "user_id": user_id,
            "username": username,
            "full_name": full_name,
            "register_date": date,
            "money": 0,
            "rank": 0,
            "white_list": "",
            "count_spam": 0,
            "interval": 1,
            "recently_spams": [],
            "last_message_id": 0,
            "last_func": "main"
        }
        await self.users_collection.insert_one(data)

    async def check_user_id(self, user_id: int):
        # Перевірка наявності користувача через проекцію
        user = await self.users_collection.find_one({"user_id": user_id}, {"_id": 1})
        return user is not None

    async def new_last_func_value(self, user_id: int, fnc: str):
        await self.users_collection.update_one({"user_id": user_id}, {"$set": {"last_func": fnc}})

    async def read_last_func_value(self, user_id: int):
        user = await self.users_collection.find_one({"user_id": user_id}, {"last_func": 1})
        return user["last_func"] if user else None

    async def new_money_value(self, user_id: int, money: int):
        await self.users_collection.update_one({"user_id": user_id}, {"$set": {"money": money}})

    async def new_rank_value(self, user_id: int, rank: int):
        await self.users_collection.update_one({"user_id": user_id}, {"$set": {"rank": rank}})

    async def read_user_money(self, user_id: int):
        user = await self.users_collection.find_one({"user_id": user_id}, {"money": 1})
        return user["money"] if user else None

    async def read_white_list(self, user_id: int):
        user = await self.users_collection.find_one({"user_id": user_id}, {"white_list": 1})
        return user["white_list"] if user else ''

    async def write_white_list(self, user_id: int, number: str):
        await self.users_collection.update_one(
            {"user_id": user_id},
            {"$set": {"white_list": number}}
        )

    async def read_user_rank(self, user_id: int):
        user = await self.users_collection.find_one({"user_id": user_id}, {"rank": 1})
        return user["rank"] if user else 0

    async def read_user_date(self, user_id: int):
        user = await self.users_collection.find_one({"user_id": user_id}, {"register_date": 1})
        return user["register_date"] if user else ''

    async def read_last_auto_increment(self):
        count = await self.users_collection.count_documents({})
        return count

    async def read_total_spam_count(self):
        result = await self.users_collection.aggregate(
            [{"$group": {"_id": None, "total": {"$sum": "$count_spam"}}}]
        ).to_list(length=1)
        return result[0]["total"] if result else 0

    async def get_profile_information(self, user_id: int):
        user = await self.users_collection.find_one(
            {"user_id": user_id},
            {"money": 1, "white_list": 1, "rank": 1, "register_date": 1, "count_spam": 1, "interval": 1}
        )
        return user if user else {"money": 0, "white_list": "", "rank": 0, "register_date": "", "count_spam": 0, "interval": 1}

    async def write_new_spam_attack(self, user_id: int):
        await self.users_collection.update_one({"user_id": user_id}, {"$inc": {"count_spam": 1}})

    async def write_new_last_message_id(self, user_id: int, message_id: int):
        await self.users_collection.update_one({"user_id": user_id}, {"$set": {"last_message_id": message_id}})

    async def read_last_message_id(self, user_id: int):
        user = await self.users_collection.find_one({"user_id": user_id}, {"last_message_id": 1})
        return user["last_message_id"] if user else 0

    async def read_all_count_spam_attacks(self):
        result = await self.users_collection.aggregate(
            [{"$group": {"_id": None, "total": {"$sum": "$count_spam"}}}]
        ).to_list(length=1)
        return result[0]["total"] if result else 0

    async def read_count_users(self):
        count = await self.users_collection.count_documents({})
        return count

    async def read_users_id(self):
        users = await self.users_collection.find({}, {"user_id": 1}).to_list()
        return [user["user_id"] for user in users]

    async def read_interval_for_spam(self, user_id: int):
        user = await self.users_collection.find_one({"user_id": user_id}, {"interval": 1, "_id": 0})
        return user.get("interval") if user else None

    async def write_interval(self, user_id: int, interval: int):
        await self.users_collection.update_one({"user_id": user_id}, {"$set": {"interval": interval}})

    async def search_user(self, user_id: int):
        user = await self.users_collection.find_one(
            {"user_id": user_id},
            {"username": 1, "full_name": 1, "money": 1, "rank": 1, "count_spam": 1, "register_date": 1, "_id": 0}
        )
        return user

    async def is_number_in_white_list(self, number: str) -> bool:
        user = await self.users_collection.find_one({"white_list": number}, {"_id": 1})
        return user is not None

    async def add_recent_spam(self, user_id: int, number: str, interval: int, spam_type: str, time: int):
        """
        Додає новий запис до recently_spams. Якщо кількість записів перевищує 3, видаляє найстаріший.
        """
        new_spam = {"number": number, "interval": interval, "date": datetime.today().strftime('%Y-%m-%d %H:%M:%S'), "type": spam_type, "time": time}
        await self.users_collection.update_one(
            {"user_id": user_id},
            {
                "$push": {
                    "recently_spams": {
                        "$each": [new_spam],
                        "$slice": -7  # Зберігає останні 3 елементи
                    }
                }
            }
        )

    async def get_recent_spams(self, user_id: int):
        """
        Повертає до 3 останніх записів з поля recently_spams.
        """
        user = await self.users_collection.find_one({"user_id": user_id}, {"recently_spams": 1})
        return user.get("recently_spams", []) if user else []


    async def start_spam_BD_operation(self, user_id: int, time: int, spam_type: str, number: str, interval: int):
        result = await self.users_collection.find_one_and_update(
            {"user_id": user_id},
            {
                "$set": {"last_func": "end_spam"},
                "$push": {
                    "recently_spams": {
                        "$each": [{
                            "number": number,
                            "interval": interval,
                            "date": datetime.today().strftime('%Y-%m-%d %H:%M:%S'),
                            "type": spam_type,
                            "time": time
                        }],
                        "$slice": -7
                    }
                },
                "$inc": {"count_spam": 1}
            },
            return_document=True,  # Повернути новий документ
            projection={"interval": 1, "_id": 0}  # Повернути лише "interval"
        )

        return result.get("interval") if result else None

# from motor.motor_asyncio import AsyncIOMotorClient
# from datetime import datetime
#
# class BD:
#     def __init__(self):
#         self.client = None
#         self.db = None
#         self.users_collection = None
#
#     async def connect(self):
#         # Підключення до MongoDB з налаштуваннями пулу з'єднань для оптимізації
#         self.client = AsyncIOMotorClient(
#             "mongodb://vzxaqNVwU7yonqHsdwJz:PwqifdH4sUmg9uBBc69E@93.113.25.38:27017/",
#             minPoolSize=5, maxPoolSize=50
#         )
#         #"mongodb://qreytol:0687@localhost:27017"
#         #"mongodb://vzxaqNVwU7yonqHsdwJz:PwqifdH4sUmg9uBBc69E@93.113.25.38:27017/"
#         self.db = self.client["users_database"]
#         self.users_collection = self.db["users"]
#
#         # Індекси для часто використовуваних полів та їх комбінацій
#         await self.users_collection.create_index("user_id", unique=True)
#         await self.users_collection.create_index("interval")
#         await self.users_collection.create_index("last_func")
#         await self.users_collection.create_index("last_message_id")
#         await self.users_collection.create_index([("user_id", 1), ("interval", 1)])
#         await self.users_collection.create_index([("user_id", 1), ("last_message_id", 1)])
#         await self.users_collection.create_index("white_list")
#
#     async def close(self):
#         # Закриття підключення до MongoDB
#         if self.client:
#             self.client.close()
#
#     async def write_data(self, user_id: int, username: str, full_name: str, date: str):
#         # Вставка нового користувача з усіма полями
#         data = {
#             "user_id": user_id,
#             "username": username,
#             "full_name": full_name,
#             "register_date": date,
#             "money": 0,
#             "rank": 0,
#             "white_list": "",
#             "count_spam": 0,
#             "interval": 1,
#             "recently_spams": "",
#             "last_message_id": 0,
#             "last_func": "main"
#         }
#         await self.users_collection.insert_one(data)
#
#     async def check_user_id(self, user_id: int):
#         # Перевірка наявності користувача через проекцію
#         user = await self.users_collection.find_one({"user_id": user_id}, {"_id": 1})
#         return user is not None
#
#     async def new_last_func_value(self, user_id: int, fnc: str):
#         await self.users_collection.update_one({"user_id": user_id}, {"$set": {"last_func": fnc}})
#
#     async def read_last_func_value(self, user_id: int):
#         user = await self.users_collection.find_one({"user_id": user_id}, {"last_func": 1})
#         return user["last_func"] if user else None
#
#     async def new_money_value(self, user_id: int, money: int):
#         await self.users_collection.update_one({"user_id": user_id}, {"$set": {"money": money}})
#
#     async def new_rank_value(self, user_id: int, rank: int):
#         await self.users_collection.update_one({"user_id": user_id}, {"$set": {"rank": rank}})
#
#     async def read_user_money(self, user_id: int):
#         user = await self.users_collection.find_one({"user_id": user_id}, {"money": 1})
#         return user["money"] if user else None
#
#     async def read_white_list(self, user_id: int):
#         user = await self.users_collection.find_one({"user_id": user_id}, {"white_list": 1})
#         return user["white_list"] if user else ''
#
#     async def write_white_list(self, user_id: int, number: str):
#         await self.users_collection.update_one(
#             {"user_id": user_id},
#             {"$set": {"white_list": number}}
#         )
#
#     async def read_user_rank(self, user_id: int):
#         user = await self.users_collection.find_one({"user_id": user_id}, {"rank": 1})
#         return user["rank"] if user else 0
#
#     async def read_user_date(self, user_id: int):
#         user = await self.users_collection.find_one({"user_id": user_id}, {"register_date": 1})
#         return user["register_date"] if user else ''
#
#     async def read_last_auto_increment(self):
#         count = await self.users_collection.count_documents({})
#         return count
#
#     async def read_total_spam_count(self):
#         result = await self.users_collection.aggregate(
#             [{"$group": {"_id": None, "total": {"$sum": "$count_spam"}}}]
#         ).to_list(length=1)
#         return result[0]["total"] if result else 0
#
#     async def get_profile_information(self, user_id: int):
#         user = await self.users_collection.find_one(
#             {"user_id": user_id},
#             {"money": 1, "white_list": 1, "rank": 1, "register_date": 1, "count_spam": 1, "interval": 1}
#         )
#         return user if user else {"money": 0, "white_list": "", "rank": 0, "register_date": "", "count_spam": 0, "interval": 1}
#
#     async def write_new_spam_attack(self, user_id: int):
#         await self.users_collection.update_one({"user_id": user_id}, {"$inc": {"count_spam": 1}})
#
#     async def write_new_last_message_id(self, user_id: int, message_id: int):
#         await self.users_collection.update_one({"user_id": user_id}, {"$set": {"last_message_id": message_id}})
#
#     async def read_last_message_id(self, user_id: int):
#         user = await self.users_collection.find_one({"user_id": user_id}, {"last_message_id": 1})
#         return user["last_message_id"] if user else 0
#
#     async def read_all_count_spam_attacks(self):
#         result = await self.users_collection.aggregate(
#             [{"$group": {"_id": None, "total": {"$sum": "$count_spam"}}}]
#         ).to_list(length=1)
#         return result[0]["total"] if result else 0
#
#     async def read_count_users(self):
#         count = await self.users_collection.count_documents({})
#         return count
#
#     async def read_users_id(self):
#         users = await self.users_collection.find({}, {"user_id": 1}).to_list()
#         return [user["user_id"] for user in users]
#
#     async def read_interval_for_spam(self, user_id: int):
#         user = await self.users_collection.find_one({"user_id": user_id}, {"interval": 1, "_id": 0})
#         return user.get("interval") if user else None
#
#     async def write_interval(self, user_id: int, interval: int):
#         await self.users_collection.update_one({"user_id": user_id}, {"$set": {"interval": interval}})
#
#     async def search_user(self, user_id: int):
#         user = await self.users_collection.find_one(
#             {"user_id": user_id},
#             {"username": 1, "full_name": 1, "money": 1, "rank": 1, "count_spam": 1, "register_date": 1, "_id": 0}
#         )
#         return user
#
#     async def is_number_in_white_list(self, number: str) -> bool:
#         """
#         Перевіряє, чи існує конкретне значення в white_list серед усіх користувачів.
#         """
#         user = await self.users_collection.find_one({"white_list": number}, {"_id": 1})
#         return user is not None
#
#
# # import aiosqlite
# # from asyncio import Lock
# # from datetime import datetime
# #
# # class BD:
# #     def __init__(self):
# #         self.db_name = 'Databases/users_DB.db'
# #         self.type_list = {'black': 'black_list', 'white': 'white_list'}
# #         self.lock = Lock()
# #         self.conn = None
# #
# #     async def _get_connection(self):
# #         if self.conn is None:
# #             self.conn = await aiosqlite.connect(self.db_name)
# #         return self.conn
# #
# #     async def _close_connection(self):
# #         if self.conn:
# #             await self.conn.close()
# #             self.conn = None
# #
# #     async def __aenter__(self):
# #         await self._get_connection()
# #         return self
# #
# #     async def __aexit__(self, exc_type, exc, tb):
# #         await self._close_connection()
# #
# #     async def _execute(self, query, params=(), many=False):
# #         async with self.lock:
# #             conn = await self._get_connection()
# #             async with conn.cursor() as cursor:
# #                 try:
# #                     if many:
# #                         await cursor.executemany(query, params)
# #                     else:
# #                         await cursor.execute(query, params)
# #                     await conn.commit()
# #                 except Exception as e:
# #                     await conn.rollback()
# #                     raise e
# #
# #
# #     async def _fetchone(self, query, params=()):
# #         async with self.lock:
# #             conn = await self._get_connection()
# #             async with conn.cursor() as cursor:
# #                 await cursor.execute(query, params)
# #                 return await cursor.fetchone()
# #
# #     async def _fetchall(self, query, params=()):
# #         async with self.lock:
# #             conn = await self._get_connection()
# #             async with conn.cursor() as cursor:
# #                 await cursor.execute(query, params)
# #                 return await cursor.fetchall()
# #
# #     async def write_data(self, user_id: int, username: str, full_name: str, date: str):
# #         query = '''INSERT INTO users ("user_id","username","full_name","register_date") VALUES (?, ?, ?, ?)'''
# #         await self._execute(query, (user_id, username, full_name, date))
# #
# #     async def check_user_id(self, user_id: int):
# #         query = '''SELECT 1 FROM users WHERE user_id = ?'''
# #         result = await self._fetchone(query, (user_id,))
# #         return result is not None
# #
# #     async def new_last_func_value(self, user_id: int, fnc: str):
# #         query = '''UPDATE users SET last_func = ? WHERE user_id = ?'''
# #         await self._execute(query, (fnc, user_id))
# #
# #     async def read_last_func_value(self, user_id: int):
# #         query = '''SELECT last_func FROM users WHERE user_id = ?'''
# #         result = await self._fetchone(query, (user_id,))
# #         return result[0] if result else None
# #
# #     async def new_money_value(self, user_id: int, money: int):
# #         query = '''UPDATE users SET money = ? WHERE user_id = ?'''
# #         await self._execute(query, (money, user_id))
# #
# #
# #     async def new_rank_value(self, user_id: int, rank: int):
# #         query = '''UPDATE users SET rank = ? WHERE user_id = ?'''
# #         await self._execute(query, (rank, user_id))
# #
# #
# #     async def read_user_money(self, user_id: int):
# #         query = '''SELECT money FROM users WHERE user_id = ?'''
# #         result = await self._fetchone(query, (user_id,))
# #         return result[0] if result else None
# #
# #     async def read_white_list(self, user_id: int) -> str:
# #         query = '''SELECT white_list FROM users WHERE user_id = ?'''
# #         result = await self._fetchone(query, (user_id,))
# #         return result[0] if result else ''
# #
# #     async def write_white_list(self, user_id: int, variable_value: str) -> None:
# #         query = '''UPDATE users SET white_list = ? WHERE user_id = ?'''
# #         await self._execute(query, (variable_value, user_id))
# #
# #     async def read_user_rank(self, user_id: int) -> int:
# #         query = '''SELECT rank FROM users WHERE user_id = ?'''
# #         result = await self._fetchone(query, (user_id,))
# #         return result[0] if result else 0
# #
# #     async def read_user_date(self, user_id: int) -> str:
# #         query = '''SELECT register_date FROM users WHERE user_id = ?'''
# #         result = await self._fetchone(query, (user_id,))
# #         return result[0] if result else ''
# #
# #     async def read_last_auto_increment(self) -> int:
# #         query = '''SELECT MAX(unique_id) FROM users'''
# #         result = await self._fetchone(query)
# #         return result[0] if result else 0
# #
# #     async def read_total_spam_count(self) -> int:
# #         query = '''SELECT SUM(count_spam) AS total_spam_count FROM users'''
# #         result = await self._fetchone(query)
# #         return result[0] if result else 0
# #
# #     async def get_profile_information(self, user_id: int):
# #         query = '''SELECT money, white_list, rank, register_date, count_spam, interval  FROM users WHERE user_id = ?'''
# #         result = await self._fetchone(query, (user_id,))
# #         return result if result else [0, '', 0, '', 0, 1]
# #
# #
# #     async def write_new_spam_attack(self, user_id: int) -> None:
# #         query = '''UPDATE users SET count_spam = count_spam + 1 WHERE user_id = ?'''
# #         await self._execute(query, (user_id,))
# #
# #
# #     async def write_new_last_message_id(self, user_id: int, message_id: int) -> None:
# #         query = '''UPDATE users SET last_message_id = ? WHERE user_id = ?'''
# #         await self._execute(query, (message_id, user_id))
# #
# #
# #     async def read_last_message_id(self, user_id: int) -> int:
# #         query = '''SELECT last_message_id FROM users WHERE user_id = ?'''
# #         result = await self._fetchone(query, (user_id,))
# #         return result[0] if result else 0
# #
# #
# #     async def read_all_count_spam_attacks(self) -> int:
# #         query = '''SELECT SUM(count_spam) FROM users'''
# #         result = await self._fetchone(query)
# #         return result[0] if result else 0
# #
# #     async def read_count_users(self) -> int:
# #         query = '''SELECT COUNT(user_id) FROM users'''
# #         result = await self._fetchone(query)
# #         return result[0] if result else 0
# #
# #
# #     async def read_users_id(self) -> int:
# #         query = '''SELECT user_id FROM users'''
# #         result = await self._fetchall(query)
# #         return result
# #
# #
# #     async def read_interval_for_spam(self, user_id):
# #         query = '''SELECT interval FROM users WHERE user_id = ?'''
# #         result = await self._fetchone(query, (user_id,))
# #         return result
# #
# #
# #     async def write_interval(self, user_id: int, interval: int) -> None:
# #         query = '''UPDATE users SET interval = ? WHERE user_id = ?'''
# #         await self._execute(query, (interval, user_id))
# #
# #
# #     async def read_last_spam(self, user_id: int):
# #         query = '''SELECT recently_spams FROM users WHERE user_id = ?'''
# #         res = await self._fetchone(query, (user_id,))
# #         return res
# #
# #     async def update_last_spam(self, user_id: int, number: str):
# #         query = '''UPDATE users SET recently_spams = ? WHERE user_id = ?'''
# #         res = await self.read_last_spam(user_id)
# #         if res[0] != '':
# #             if len(res[0]) == 12:
# #                 await self._execute(query, (f"{res[0]} {number}", user_id))
# #             else:
# #                 await self._execute(query, (f"{res[0].split()[-1]} {number}", user_id))
# #         else:
# #             await self._execute(query, (number, user_id))
# #
# #
# #     async def search_user(self, user_id: int):
# #         query = '''SELECT username, full_name, money, rank, count_spam, register_date FROM users WHERE user_id = ?'''
# #         res = await self._fetchone(query, (user_id,))
# #         return res
