import requests
import aiohttp
import asyncio
from time import sleep
from datetime import datetime, timedelta
from information.spam_full_info import *
from Databases.BD_functional import *
from for_sms_spam.services_for_spam import get_services
import json

bd = BD()

check_start = set()


def format_phone(number: str, format: str) -> str:
    g = [i for i, k in enumerate(format) if k == '#']
    format = list(format)
    for i in range(len(g)):
        format[g[i]] = number[i]
    return ''.join(format)


async def start_spam_sms(number: str, time: int, variable_spam: str, id_user: int, interval: int = 0):
    #print(number, time, variable_spam, interval)
    check_start.add(id_user)
    end = datetime.now() + timedelta(seconds=time)
    async with aiohttp.ClientSession() as session:
        while id_user in check_start and datetime.now() <= end:
            for cur in get_services(number, variable_spam):
                if id_user not in check_start or datetime.now() >= end:
                    break
                url = cur["url"]
                headers = cur["headers"]
                data_type = cur["spam_type"]
                data = cur["data"]
                send = cur["send"]
                # try:
                #     if send == "post":
                #         if data_type == "data":
                #             await session.post(url=url, headers=headers, data=data, timeout=5, proxy=None)
                #         else:
                #             await session.post(url=url, headers=headers, json=data, timeout=5, proxy=None)
                #     else:
                #         if data_type == "data":
                #             await session.get(url=url, headers=headers, data=data, timeout=5, proxy=None)
                #         else:
                #             await session.get(url=url, headers=headers, json=data, timeout=5, proxy=None)
                #     #print(res.text)
                # except:
                #     pass
                await asyncio.sleep(interval)

    if id_user in check_start:
        check_start.remove(id_user)
        return "end"


# a = session.post('https://oauth.av.ru/check-phone',headers={'accept': '*/*','accept-encoding': 'gzip, deflate, br','accept-language': 'ru,uk;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6','content-length': '30','content-type': 'application/json','cookie': '_gcl_au=1.1.382800986.1672241092; tmr_lvid=3394eaf463ff847effcdba90ea34e509; tmr_lvidTS=1672241094153; _gid=GA1.2.614356348.1672241094; session-cookie=1734fe6a418ba52908dffcb9beb261f5c6c52b2e19578d8601bce35198a14dbca2494dcdf067d7ea2ce76d6a6715c178; _ga=GA1.1.1006516927.1672241094; cted=modId%3Dlgdf6xru%3Bclient_id%3D1006516927.1672241094; _ym_uid=1672241097441330040; _ym_d=1672241097; _ym_isad=2; _ym_visorc=b; tmr_detect=0%7C1672241097791; XSRF-TOKEN=eyJpdiI6ImlIUGVhWVlVcldrS21KSXdOU3hEZ1E9PSIsInZhbHVlIjoieG1RUm5CYytqT3NPOHpEOUNycXR3Vld4dG5LTlhBK080djZLcWlCNWtheGFsd2NXejNhMWpyM053dzJMME43TzcxajljKzZhVlp1Tkl4QmhZcHZIYitHNlNOZDJ0Vjk3WUdleVovNTZSVUdJNlJzWVhtanBQOVh4WmpZbjF0a1EiLCJtYWMiOiI0ZDYzNWQxMGI4NzU5NTA1Y2Y2YTE0NDk5OTEyZTdiYTdhNGQzMjA5Mjg3NTFkZGM5NWI4MmJhYjQxZWJlNmNmIiwidGFnIjoiIn0%3D; laravel_session=eyJpdiI6InExbHVVZGhUSUU4dHh3ck93bEM3aUE9PSIsInZhbHVlIjoiNlU1SUVNaGpGRHRyaFBlSmM5ZDdhZFJPa3Z2anpMdkVtQ29QajJmaGd1ZWs3MnNGcVNPYmdPN2hnSkxwQ2t0aGh6UEdlTGJscW1ncDBEbG9uYmZiTjJXZnZ3SUxwdUVZcnF5QlJvM1Y2bXcza1Bja2I2WVdma1RqZkhPbjlFOWkiLCJtYWMiOiI0MDhiZTcxNjQwZDUyNzJkZjZhMGNhOTc0MzYyNmVlMDk0YzM0ZjMyZjBkOTdmYTRiNTU0M2UxY2ZjMTkxYWY2IiwidGFnIjoiIn0%3D; _ga_D2FVM87H39=GS1.1.1672241094.1.1.1672241104.0.0.0','origin': 'https://oauth.av.ru','referer': 'https://oauth.av.ru/code','sec-ch-ua': '"Not?A_Brand";v="8", "Chromium";v="108", "Microsoft Edge";v="108"','sec-ch-ua-mobile': '?0','sec-ch-ua-platform': "Windows",'sec-fetch-dest': 'empty','sec-fetch-mode': 'cors','sec-fetch-site': 'same-origin','user-agent': get_agent(),'x-ajax-token': '5397441c5657d614e0c9a36a6724bf58474703e2cff9a2d0b6db56bdce599d11','x-csrf-token': 'SM2HVxtbR8MlAkDvED3CgVUEejHUZ5aHLpD6c3Kh','x-requested-with': 'XMLHttpRequest','x-xsrf-token': 'eyJpdiI6ImlIUGVhWVlVcldrS21KSXdOU3hEZ1E9PSIsInZhbHVlIjoieG1RUm5CYytqT3NPOHpEOUNycXR3Vld4dG5LTlhBK080djZLcWlCNWtheGFsd2NXejNhMWpyM053dzJMME43TzcxajljKzZhVlp1Tkl4QmhZcHZIYitHNlNOZDJ0Vjk3WUdleVovNTZSVUdJNlJzWVhtanBQOVh4WmpZbjF0a1EiLCJtYWMiOiI0ZDYzNWQxMGI4NzU5NTA1Y2Y2YTE0NDk5OTEyZTdiYTdhNGQzMjA5Mjg3NTFkZGM5NWI4MmJhYjQxZWJlNmNmIiwidGFnIjoiIn0='},json={"phone": f'+{number[:1]} ({number[1:4]}) {number[4:7]}-{number[7:9]}-{number[9:11]}'})

# a = session.post('https://www.xfit.ru/xfitnew_ajax/register/get_sms.php',headers={'user-agent': get_agent(),'x-requested-with': 'XMLHttpRequest'},data={'TYPE': 'REGISTRATION','backurl': '/personal/','REGISTER[NAME]': name,'REGISTER[LAST_NAME]': '','REGISTER[PERSONAL_BIRTHDAY]': '','REGISTER[PERSONAL_CITY]': '','REGISTER[PERSONAL_PHONE]': f'+{number[:1]} ({number[1:4]}) {number[4:7]}-{number[7:9]}-{number[9:11]}','REGISTER[EMAIL]': email})

# UKR

# a = session.post('https://dnipro-m.ua/phone-verification/',headers={'accept': 'application/json, text/plain, */*','accept-encoding': 'gzip, deflate, br','accept-language': 'ru,uk;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6','content-length': '24','content-type': 'application/json;charset=UTF-8','cookie': 'PHPSESSID=l5t070lhpugvmdemjc117meb4i; session_hash=9d9ba99cb6b7ee6b56e5fdef1dd1e109; ab_1=2; logged_in_as=c38cdce2f7ef0094f910220849aee84a3613eb500f51202d492282b1d416cf91a%3A2%3A%7Bi%3A0%3Bs%3A12%3A%22logged_in_as%22%3Bi%3A1%3BN%3B%7D; manager_store=9f8a6a348bfddc4e1484e8c2b620e744a46020143d5011858217908bfa12f43ca%3A2%3A%7Bi%3A0%3Bs%3A13%3A%22manager_store%22%3Bi%3A1%3BN%3B%7D; gclid=939156d81035356c746423ecca0a2cf4a2748f879bd3dc65cfa6250fb7064ccea%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22gclid%22%3Bi%3A1%3Bs%3A8%3A%22dnipro-m%22%3B%7D; lang_r=8053f38b7e4ac8a0829af5cbea1f4efbc31c72f8fbf68282024cc0f4d67fa1e0a%3A2%3A%7Bi%3A0%3Bs%3A6%3A%22lang_r%22%3Bi%3A1%3Bi%3A1%3B%7D; language=0480298520a8be04ccfd813520616a13a8aa0fb2db683a1126b77f187eca16c3a%3A2%3A%7Bi%3A0%3Bs%3A8%3A%22language%22%3Bi%3A1%3Bs%3A2%3A%22uk%22%3B%7D; translations_pushed=92f83c1f3a434aeae744854c974cdb236df315cbe39e518ed7234b1ea9a0cd88a%3A2%3A%7Bi%3A0%3Bs%3A19%3A%22translations_pushed%22%3Bi%3A1%3Bi%3A1%3B%7D; _csrf-frontend=434d87695d524a3cdcfa74ee1631bf03bdeb4be546ea8e92f1de6b9e44f6c04ba%3A2%3A%7Bi%3A0%3Bs%3A14%3A%22_csrf-frontend%22%3Bi%3A1%3Bs%3A32%3A%222RI7CE7A78LI4Arhq04WwRH0Q-ah0YxS%22%3B%7D; _gcl_au=1.1.653602827.1672399510; sc=536904F7-61A7-967F-CE3E-9C642B2EEDF4; _gid=GA1.2.1931773835.1672399549; _hjFirstSeen=1; _hjIncludedInSessionSample=0; _hjSession_1116764=eyJpZCI6ImFmMWQzOGM0LTE3YjEtNDllMC1iOTkyLTNjNmQzZDkzOWE5NCIsImNyZWF0ZWQiOjE2NzIzOTk1NDk0NDYsImluU2FtcGxlIjpmYWxzZX0=; _hjAbsoluteSessionInProgress=0; _fbp=fb.1.1672399549583.516482106; csfp=5fff11909f2a1868e3f28c3f794f1b6c; __zlcmid=1DglULtoRAjPmm1; g_state={"i_p":1672406868974,"i_l":1}; _gat_UA-87493814-1=1; _gcl_aw=GCL.1672399698.Cj0KCQiAtbqdBhDvARIsAGYnXBMxzgyYOyxiZlvl2RrugiHegSOMqZlHZ5vtNmr3GWwuW61QTA10b7gaAt7iEALw_wcB; _ga_4JZL75V9F8=GS1.1.1672399549.1.1.1672399698.40.0.0; _dc_gtm_UA-87493814-1=1; _ga_1QMTESJ6M0=GS1.1.1672399550.1.1.1672399700.57.0.0; _hjSessionUser_1116764=eyJpZCI6IjgxNWFkNTdiLTE0NWMtNThkZS05MzU3LTcwOTc1MmVjZjJiYyIsImNyZWF0ZWQiOjE2NzIzOTk1NDk0MjksImV4aXN0aW5nIjp0cnVlfQ==; _ga=GA1.2.49567252.1672399549; _gac_UA-87493814-1=1.1672399705.Cj0KCQiAtbqdBhDvARIsAGYnXBMxzgyYOyxiZlvl2RrugiHegSOMqZlHZ5vtNmr3GWwuW61QTA10b7gaAt7iEALw_wcB','origin': 'https://dnipro-m.ua','referer': 'https://dnipro-m.ua/sredstva-individualnoj-zashhity/zashchitnye-ochki/?gclid=Cj0KCQiAtbqdBhDvARIsAGYnXBMxzgyYOyxiZlvl2RrugiHegSOMqZlHZ5vtNmr3GWwuW61QTA10b7gaAt7iEALw_wcB','sec-ch-ua': '"Not?A_Brand";v="8", "Chromium";v="108", "Microsoft Edge";v="108"','sec-ch-ua-mobile': '?0','sec-ch-ua-platform': "Windows",'sec-fetch-dest': 'empty','sec-fetch-mode': 'cors','sec-fetch-site': 'same-origin','user-agent': get_agent(),'x-csrf-token': 'SqcDm_I4z8_rcawUoh2zsyp8V12SBkKgEhYmyTNmMxx49UqssX34jtxJ4F2WXMHbW0xjCuVUCpBDO0ehAz9LTw==','x-requested-with': 'XMLHttpRequest'},json={"phone": number})


# obratniy zvonok
# https://luxoptica.ua/ua/sunglasses/
# https://ochki.kiev.ua/?gclid=Cj0KCQiAtbqdBhDvARIsAGYnXBMZrm7S9fIMQu-yuLKygdoQHljP9TJCy7jtBvTxMWnJrDKFzEs9UXEaArxdEALw_wcB
