from pymongo import MongoClient

async def fix_recently_spams_field():
    # Підключення до MongoDB
    client = MongoClient("mongodb://vzxaqNVwU7yonqHsdwJz:PwqifdH4sUmg9uBBc69E@93.113.25.38:27017/")
    db = client["users_database"]
    users_collection = db["users"]

    # Знайти документи, де recently_spams не є масивом
    invalid_documents = users_collection.find({"recently_spams": {"$not": {"$type": "array"}}})

    # Замінити тип на масив
    for doc in invalid_documents:
        print(f"Fixing document ID: {doc['_id']}")
        users_collection.update_one(
            {"_id": doc["_id"]},
            {"$set": {"recently_spams": []}}  # Оновлення поля на порожній масив
        )

    print("All invalid documents fixed.")

# Виклик функції
import asyncio
asyncio.run(fix_recently_spams_field())
