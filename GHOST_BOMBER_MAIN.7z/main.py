import asyncio
import logging
import requests
import json
import aiohttp
from aiogram.methods import DeleteWebhook
from aiogram.client.session.aiohttp import AiohttpSession

from aiogram import Bot, Dispatcher, html
from aiogram.client.default import DefaultBotProperties
from aiogram.filters import CommandStart
from aiogram.types import Message
from aiogram import F
from aiogram import types
from aiogram.types.input_file import FSInputFile
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.filters import StateFilter

from Keyboard.base_keyboard import main_keyboard
from Texts.base_text import *
from Databases.BD_functional import *
from ADM_Panel.ADMIN_panel import *
from ADM_Panel.ADM_state import *
from Keyboard.spam_keyboard import *
from Keyboard.interval_keyboard import *
from Keyboard.chanel_keyboard import *
from Keyboard.about_user_keyboard import *
from Keyboard.ugoda_keyboard import *
from Keyboard.back_keyboard import *
from Keyboard.profile_keyboard import *
from Keyboard.about_service import *
from Keyboard.exit_keyboard import *
from Keyboard.white_list_keyboard import *
from Databases.white_list_state import add_white_list_spam as while_list_state
from Databases.recently_spam_state import *
from information.special_banned_number import banned_number
from Keyboard.recently_spam_keyboard import *

from Databases.base_states import information_for_spam as spam_state
from for_sms_spam.SMS_SPAM import *
from for_sms_spam.services_for_spam import get_count_of_services

TOKEN = "5767871314:AAFK8iEjmRjkltx7QXH8MzZR3zVlBzWkntA"

#main 5640723468:AAEq32t7jC49vvUVhg8ZvCcS4VlXuZmTaH8
#TEST 5767871314:AAFK8iEjmRjkltx7QXH8MzZR3zVlBzWkntA

session = AiohttpSession()
session._connector_init = {'ssl': False}

bot = Bot(token=TOKEN, session=session)

storage = MemoryStorage()

dp = Dispatcher(storage=storage)

DB = BD()


async def on_startup():
    await DB.connect()

async def on_shutdown():
    await DB.close()


def valid_number(phone: str) -> str:
    return ''.join([i for i in phone if i.isdigit()])


async def send_messages(ids, text, photo=None, anim=None):
    for i in range(len(ids)):
        try:
            if photo is None and anim is None:
                await bot.send_message(chat_id=ids[i], text=text, reply_markup=exit_keyboard.as_markup(),
                                       parse_mode='Markdown')
            elif anim is None:
                await bot.send_photo(chat_id=ids[i], photo=photo, caption='' if text is None else text, reply_markup=exit_keyboard.as_markup(), parse_mode='Markdown')
            else:
                await bot.send_sticker(chat_id=ids[i], sticker=anim, reply_markup=exit_keyboard.as_markup())

            if i > 0 and i % 500 == 0:
                await asyncio.sleep(10)
        except:
            pass


@dp.message(CommandStart())
async def msg(message: Message, state: FSMContext):
    user_id = message.from_user.id
    first_name = message.from_user.first_name
    join_user = await bot.get_chat_member(-1001801111265, user_id=user_id)
    in_bd = await DB.check_user_id(user_id)
    current_state = await state.get_state()

    if current_state is not None:
        await state.clear()

    if not in_bd:
        await DB.write_data(user_id, message.from_user.username, message.from_user.full_name,datetime.today().strftime('%Y-%m-%d %H:%M:%S'))

    await DB.new_last_func_value(user_id, "main")
    await bot.send_sticker(user_id,
                           f'{choice(["CAACAgIAAxkBAAEG9ghjpXBppcR1qdB3LdycQCJikPIfuwACZToAAuCjggdALs5mg2bPrCwE", "CAACAgIAAxkBAAEG9gRjpW-lLv4avqScE6_b4bBT19g67gACdzoAAuCjggeRGYfh-ZRYgiwE", "CAACAgIAAxkBAAEG9gZjpW-17ZzbQCbPZr_Y1q9y1DCtDgACkzoAAuCjggeUbBeLK2NJMCwE", "CAACAgIAAxkBAAEG9gJjpW-djX3WK39gK3slE4n3qB_Y0QACZDoAAuCjggf8sCNx1XiBLSwE"])}')

    if join_user.status == "administrator" or join_user.status == "creator":
        await message.reply(get_first_message(first_name,user_id), reply_markup=get_admin_keyboard(user_id).as_markup(), parse_mode="Markdown", disable_web_page_preview=True)
    elif join_user.status == "member":
        await message.reply(get_first_message(first_name,user_id), reply_markup=main_keyboard.as_markup(), parse_mode="Markdown", disable_web_page_preview=True)
    else:
        await message.answer(get_user_ugoda(), reply_markup=ugoda_service_keyboard.as_markup())
        #await message.reply(not_subscribe_text(user_id, first_name), parse_mode='Markdown', reply_markup=chanel_keyboard.as_markup())



@dp.callback_query(F.data == "accept_ugoda")
async def ugoda_func(call: types.CallbackQuery):
    user_id = call.from_user.id
    first_name = call.from_user.first_name
    await call.message.edit_text(not_subscribe_text(user_id, first_name), parse_mode='Markdown',
                        reply_markup=chanel_keyboard.as_markup())


@dp.callback_query(F.data == "spam")
async def spam_func(call: types.CallbackQuery):
    user_id = call.from_user.id
    await DB.new_last_func_value(user_id, "spam")
    await call.message.edit_text(spam_text(user_id), parse_mode="Markdown", reply_markup=spam_keyboard.as_markup())


@dp.callback_query(F.data == "back")
async def back_func(call: types.CallbackQuery, state: FSMContext):
    user_id = call.from_user.id
    first_name = call.from_user.first_name
    join_user = await bot.get_chat_member(-1001801111265, user_id=user_id)
    map_for_back = {"select_variable": "main",
                    "profile": "main",
                    "end_spam": "main",
                    "type_number": "select_variable",
                    "select_time": "type_number",
                    "main": "main",
                    'spam': 'main',
                    "change_user_inf": "adm_user_search"
                    }


    get_last_func = await DB.read_last_func_value(user_id)
    try:
        if map_for_back[get_last_func] == "main":
            current_state = await state.get_state()
            if current_state is not None:
                await state.clear()
            if join_user.status == "administrator" or join_user.status == "creator":
                await call.message.edit_text(get_first_message(first_name, user_id),
                                             reply_markup=get_admin_keyboard(user_id).as_markup(), parse_mode="Markdown",
                                             disable_web_page_preview=True)
            else:
                await call.message.edit_text(get_first_message(first_name, user_id),
                                             reply_markup=main_keyboard.as_markup(), parse_mode="Markdown",
                                             disable_web_page_preview=True)


        elif map_for_back[get_last_func] == "select_variable":
            current_state = await state.get_state()
            if current_state is not None:
                await state.clear()
            await DB.new_last_func_value(user_id, "select_variable")
            await call.message.edit_text(spam_text(user_id), parse_mode="Markdown",
                                         reply_markup=spam_keyboard.as_markup())

        elif map_for_back[get_last_func] == "type_number":
            await DB.new_last_func_value(user_id, "type_number")
            await call.message.edit_text(get_first_step_for_sms_spam(user_id), parse_mode='Markdown',
                                         reply_markup=back_keyboard.as_markup())
            await state.set_state(spam_state.phone)

        elif map_for_back[get_last_func] == "adm_user_search":
            user_inf_gt = await state.get_data()
            await DB.new_last_func_value(user_id, "main")
            user_inf = await DB.search_user(user_inf_gt["user_search_id"])
            user_id = call.from_user.id
            mes_id = await DB.read_last_message_id(user_id)
            if user_inf:
                await bot.edit_message_text(
                    text=get_search_user_text(user_inf['username'], user_inf['full_name'], user_inf['money'], user_inf['rank'],user_inf['count_spam'], user_inf['register_date'],
                                              user_inf_gt["user_search_id"]), chat_id=user_id, message_id=mes_id,
                    parse_mode='Markdown',
                    reply_markup=user_info_keyboard.as_markup())
                await state.set_state(search_user_state.user_type)
    except Exception as ex:
        await call.message.edit_text("Виникла невідома помилка. Введіть будь ласка /start")
        print(ex)



@dp.callback_query(F.data == "valid")
async def valid_func(call: types.CallbackQuery):
    user_id = call.from_user.id
    first_name = call.from_user.first_name
    join_user = await bot.get_chat_member(-1001801111265, call.from_user.id)

    if join_user.status == 'member':
        await call.message.edit_text(get_first_message(first_name, user_id),reply_markup=main_keyboard.as_markup(), parse_mode='Markdown', disable_web_page_preview=True)
    else:
        await call.answer(attempt_cheating(), show_alert=True)


@dp.callback_query(F.data == "profile")
async def profile_func(call: types.CallbackQuery):
    user_id = call.from_user.id
    first_name = call.from_user.first_name
    await DB.new_last_func_value(user_id, "profile")
    get_rank = await DB.read_user_rank(user_id)
    get_need_inf = await DB.get_profile_information(user_id)
    #print(get_need_inf)
    await call.message.edit_text(profile_text(first_name, user_id, get_need_inf['white_list'], get_need_inf['money'], get_need_inf['rank'], get_need_inf['register_date'], get_need_inf['count_spam'], get_need_inf['interval']), parse_mode='Markdown', reply_markup=get_profile(get_rank).as_markup())


@dp.callback_query(F.data[:10] == "white_list")
async def white_list_func(call: types.CallbackQuery, state: FSMContext):
    user_id = call.from_user.id
    if call.data[11:].startswith("menu"):
        user_white_phone = await DB.read_white_list(user_id)
        await call.message.edit_text("Вівавіаіа", reply_markup=get_white_list_menu(user_white_phone!='').as_markup())
    elif call.data[11:].startswith("delete"):
        await DB.write_white_list(user_id, '')
        await call.message.answer("sdfsf", reply_markup=exit_keyboard.as_markup())
    elif call.data[11:].startswith("add"):
        await state.set_state(while_list_state.number)
        await call.message.edit_text("Введіть номер який хочете добавити в білий список")
    elif call.data[11:].startswith("change"):
        await state.set_state(while_list_state.number)
        await call.message.edit_text("Введіть номер який хочете замінити на інший")

@dp.message(StateFilter(while_list_state.number))
async def add_number_while_list_state(message: Message, state: FSMContext):
    await message.delete()
    user_id = message.from_user.id
    val_phone = valid_number(message.text)
    if len(val_phone) == 12 and val_phone.startswith("380"):
        await DB.write_white_list(user_id, val_phone)
        await state.clear()
        await message.answer("sdfsfsdf")
    elif len(val_phone) == 10 and val_phone.startswith("0"):
        await DB.write_white_list(user_id, f"38{val_phone}")
        await state.clear()
        await message.answer("sdfsfsdf")


@dp.callback_query(F.data == "change_interval")
async def change_interval(call: types.CallbackQuery):
    user_id = call.from_user.id
    get_interval = await DB.read_interval_for_spam(user_id)
    await call.message.edit_text(get_change_interval_text(user_id, get_interval), reply_markup=get_intervals(get_interval).as_markup(), parse_mode='Markdown')


@dp.callback_query(F.data[2:] == "set_interval")
async def read_interval(call: types.CallbackQuery):
    user_id = call.from_user.id
    await DB.write_interval(user_id, call.data[0])
    await call.message.edit_text(get_change_interval_text(user_id, int(call.data[0])), reply_markup=get_intervals(int(call.data[0])).as_markup(), parse_mode='Markdown')


@dp.callback_query(F.data == "info")
async def info_func(call: types.CallbackQuery):
    user_count = await DB.read_last_auto_increment()
    count_sms_spam = await DB.read_total_spam_count()
    await call.message.edit_text(info_text(user_count, count_sms_spam, get_count_of_services("sms") ,get_count_of_services("call")), parse_mode='Markdown', reply_markup=about_service_keyboard.as_markup())


@dp.callback_query(F.data == "exit_msg")
async def exit_func(call: types.CallbackQuery):
    await call.message.delete()


@dp.callback_query(F.data == "rozsilka")
async def rozsilka(call: types.CallbackQuery, state: FSMContext):
    user_id = call.from_user.id
    await state.set_state(mail_send.text_send)
    await call.message.edit_text(get_rozsilka_text(user_id), parse_mode='Markdown', reply_markup=back_keyboard.as_markup())


@dp.message(StateFilter(mail_send.text_send))
async def rozilka_state(message: Message):
    await message.delete()
    get_all_user = await DB.read_users_id()
    if message.photo:
        await send_messages(get_all_user,message.caption if message.caption else '', message.photo[0].file_id)
    elif message.animation:
        await send_messages(get_all_user, None, None, message.animation.file_id)
    else:
        await send_messages(get_all_user, message.text)



@dp.callback_query(F.data.in_({"mix", "sms", "call"}))
async def sms_func(call: types.CallbackQuery, state: FSMContext):
    user_id = call.from_user.id
    recently_number = await DB.get_recent_spams(user_id)
    await DB.write_new_last_message_id(user_id, call.message.message_id)
    await DB.new_last_func_value(user_id, "type_number")
    await state.update_data(variable_spam = call.data)
    await state.set_state(spam_state.phone)
    await call.message.edit_text(get_first_step_for_sms_spam(user_id), parse_mode='Markdown', reply_markup=get_type_number_spam_keyboard(recently_number).as_markup())


@dp.callback_query(F.data == "about_user")
async def about_user(call: types.CallbackQuery, state: FSMContext):
    user_id = call.from_user.id
    await DB.write_new_last_message_id(user_id, call.message.message_id)
    await call.message.edit_text(get_search_text(), parse_mode='Markdown', reply_markup=back_keyboard.as_markup())
    await state.set_state(search_user_state.user_search_id)


@dp.message(StateFilter(search_user_state.user_search_id))
async def search_user(message: types.CallbackQuery, state: FSMContext):
    await message.delete()
    if message.text.isnumeric():
        user_inf = await DB.search_user(int(message.text))
        user_id = message.from_user.id
        mes_id = await DB.read_last_message_id(user_id)
        if user_inf:
            await state.update_data(user_search_id = int(message.text))
            await bot.edit_message_text(text=get_search_user_text(user_inf['username'], user_inf['full_name'], user_inf['money'], user_inf['rank'],user_inf['count_spam'], user_inf['register_date'], message.text), chat_id=user_id, message_id=mes_id, parse_mode='Markdown', reply_markup=user_info_keyboard.as_markup())
            await state.set_state(search_user_state.user_type)
        else:
            await message.answer("Користувача не знайдено", reply_markup=back_keyboard.as_markup())


@dp.callback_query(StateFilter(search_user_state.user_type))
async def search_user_type(call: types.CallbackQuery, state: FSMContext):
    user_srch_id = await state.get_data()
    user_id = call.from_user.id
    mes_id = await DB.read_last_message_id(user_id)
    await DB.new_last_func_value(user_id, "change_user_inf")
    if call.data == "change_user_rank":
        await bot.edit_message_text(text=f"введіть в чат ранг для користувача з айді {user_srch_id["user_search_id"]}", chat_id=user_id, message_id=mes_id, parse_mode='Markdown', reply_markup=back_keyboard.as_markup())
        await state.set_state(search_user_state.user_rank)
    elif call.data == "change_user_balance":
        await state.set_state(search_user_state.user_balance)
        await bot.edit_message_text(text=f"введіть в чат баланс для користувача з айді {user_srch_id["user_search_id"]}", chat_id=user_id, message_id=mes_id, parse_mode='Markdown', reply_markup=back_keyboard.as_markup())



@dp.callback_query(F.data == "recently_spam_list")
async def recently_spam_list(call: types.CallbackQuery, state: FSMContext):
    user_id = call.from_user.id
    get_spams = await DB.get_recent_spams(user_id)
    #print(get_spams)
    await state.set_state(current_page_pos.pos)
    await state.update_data(pos = 1)
    if get_spams:
        number_info = get_spams[0]['number']
        interval_info = get_spams[0]['interval']
        date_info = get_spams[0]['date']
        spam_type_info = get_spams[0]['type']
        time_info = get_spams[0]['time']
        await call.message.edit_text(current_number_inform(number_info, interval_info, date_info, spam_type_info, time_info, user_id), reply_markup=get_recently_spam_keyboard(get_spams, 1).as_markup(), parse_mode='Markdown')


@dp.callback_query(StateFilter(current_page_pos.pos))
async def current_recently_spam_list(call: types.CallbackQuery, state: FSMContext):
    user_id = call.from_user.id
    current_pos = await state.get_data()
    get_spams = await DB.get_recent_spams(user_id)
    if call.data == "next_info":
        await state.update_data(pos=current_pos["pos"] + 1)
        current_pos = await state.get_data()
        number_info = get_spams[current_pos['pos']-1]['number']
        interval_info = get_spams[current_pos['pos']-1]['interval']
        date_info = get_spams[current_pos['pos']-1]['date']
        spam_type_info = get_spams[current_pos['pos']-1]['type']
        time_info = get_spams[current_pos['pos']-1]['time']
        await call.message.edit_text(current_number_inform(number_info, interval_info, date_info, spam_type_info, time_info, user_id), reply_markup=get_recently_spam_keyboard(get_spams, current_pos["pos"]).as_markup(), parse_mode='Markdown')
    elif call.data == "prev_info":
        await state.update_data(pos=current_pos["pos"] - 1)
        current_pos = await state.get_data()
        number_info = get_spams[current_pos['pos']-1]['number']
        interval_info = get_spams[current_pos['pos']-1]['interval']
        date_info = get_spams[current_pos['pos']-1]['date']
        spam_type_info = get_spams[current_pos['pos']-1]['type']
        time_info = get_spams[current_pos['pos']-1]['time']
        await call.message.edit_text(current_number_inform(number_info, interval_info, date_info, spam_type_info, time_info, user_id), reply_markup=get_recently_spam_keyboard(get_spams, current_pos["pos"]).as_markup(), parse_mode='Markdown')
    elif call.data == "info_start_spam":


@dp.message(StateFilter(search_user_state.user_balance))
async def change_user_balance(message: types.CallbackQuery, state: FSMContext):
    await message.delete()
    user_srch_id = await state.get_data()
    user_id = message.from_user.id
    mes_id = await DB.read_last_message_id(user_id)
    new_balance = int(''.join([i for i in message.text if i.isdigit() or i=='-']))
    await DB.new_money_value(user_srch_id["user_search_id"], new_balance)
    await bot.edit_message_text(
        text="Баланс користувача був змінено", chat_id=user_id, message_id=mes_id, parse_mode='Markdown',
        reply_markup=back_keyboard.as_markup())

    await state.set_state(search_user_state.user_type)


@dp.message(StateFilter(search_user_state.user_rank))
async def change_user_rank(message: types.CallbackQuery, state: FSMContext):
    await message.delete()
    user_srch_id = await state.get_data()
    user_id = message.from_user.id
    mes_id = await DB.read_last_message_id(user_id)
    await DB.new_rank_value(user_srch_id["user_search_id"], int(''.join([i for i in message.text if i.isdigit()])))
    await bot.edit_message_text(
        text="Ранг користувача був змінено", chat_id=user_id, message_id=mes_id, parse_mode='Markdown',
        reply_markup=back_keyboard.as_markup())

    await state.set_state(search_user_state.user_type)


@dp.callback_query(F.data == "active_spam")
async def send_active_spam(call: types.CallbackQuery):
    await call.message.answer(f"""
Зараз активно: `{len(check_start)}` спамів
""", reply_markup=exit_keyboard.as_markup(), parse_mode='Markdown')


@dp.callback_query(StateFilter(spam_state.phone))
async def state_for_spam_call(call: types.CallbackQuery, state: FSMContext):
    user_id = call.from_user.id
    await state.update_data(phone=call.data)
    await state.set_state(spam_state.time)
    await DB.new_last_func_value(user_id, "select_time")
    await call.message.edit_text(get_spam_time_text(user_id), parse_mode='Markdown', reply_markup=time_spam_keyboard.as_markup())


@dp.message(StateFilter(spam_state.phone))
async def state_for_spam(message: types.Message, state: FSMContext):
    await message.delete()
    user_id = message.from_user.id
    text = message.text
    val_phone = valid_number(text)

    if val_phone in banned_number or f"38{val_phone}" in banned_number:
        await message.answer("""
Не можна кидати спам на цей номер.
""", parse_mode='Markdown')
        await bot.send_message(5112839866, f"Username: {message.from_user.username}\nName: {message.from_user.full_name}\nID: {message.from_user.id}")



    elif len(val_phone) == 12 and val_phone.startswith("380"):
        check_white_list = await DB.is_number_in_white_list(val_phone)
        if check_white_list:
            await message.answer("Цей номер знаходиться в білому списку :(", reply_markup=exit_keyboard.as_markup())
        else:
            await state.update_data(phone=val_phone)
            await state.set_state(spam_state.time)
            mes_id = await DB.read_last_message_id(user_id)
            await DB.new_last_func_value(user_id, "select_time")
            await bot.edit_message_text(text=get_spam_time_text(user_id), chat_id=user_id, message_id=mes_id, parse_mode='Markdown', reply_markup=time_spam_keyboard.as_markup())
    elif len(val_phone) == 10 and val_phone.startswith("0"):
        check_white_list = await DB.is_number_in_white_list(f"38{val_phone}")
        if check_white_list:
            await message.answer("Цей номер знаходиться в білому списку :(", reply_markup=exit_keyboard.as_markup())
        else:
            await state.update_data(phone=f"38{val_phone}")
            await state.set_state(spam_state.time)
            mes_id = await DB.read_last_message_id(user_id)
            await DB.new_last_func_value(user_id, "select_time")
            await bot.edit_message_text(text=get_spam_time_text(user_id), chat_id=user_id, message_id=mes_id, parse_mode='Markdown', reply_markup=time_spam_keyboard.as_markup())


@dp.message(StateFilter(spam_state.time))
async def state_for_spam(message: types.Message, state: FSMContext):
    user_id = message.from_user.id
    first_name = message.from_user.first_name
    text = message.text
    await message.delete()
    if text.isdigit() and int(text)>=1 and int(text) <= 300:
        await state.update_data(time=int(text))
        inf = await state.get_data()
        mes_id = await DB.read_last_message_id(user_id)
        interval_spam = await DB.read_interval_for_spam(user_id)

        await DB.start_spam_BD_operation(user_id, int(inf["time"]), inf["variable_spam"], inf["phone"], interval_spam)

        await bot.edit_message_text(chat_id=user_id, message_id=int(mes_id), text=get_start_spam_text(first_name,user_id,inf["phone"], inf["variable_spam"],int(inf["time"]), True, interval_spam), parse_mode='Markdown', reply_markup=stop_spam_keyboard.as_markup())
        get_spam_status = await start_spam_sms(inf["phone"], int(inf["time"]), inf["variable_spam"], int(user_id), int(interval_spam))
        if get_spam_status == "end":
            await bot.edit_message_text(chat_id=user_id, message_id=int(mes_id), text=get_start_spam_text(first_name, user_id, inf["phone"], inf["variable_spam"], int(inf["time"]),
                                    user_id in check_start, interval_spam), parse_mode='Markdown',
                reply_markup=back_keyboard.as_markup())


@dp.callback_query(StateFilter(spam_state.time))
async def state_for_spam_callback(call: types.CallbackQuery, state: FSMContext):
    user_id = call.from_user.id
    first_name = call.from_user.first_name
    interval_spam = await DB.read_interval_for_spam(user_id)

    if call.data in {"60", "120", "180", "240", "300"}:
        await state.update_data(time=int(call.data))
        inf = await state.get_data()

        await DB.start_spam_BD_operation(user_id, int(inf["time"]), inf["variable_spam"], inf["phone"], interval_spam)
        await call.message.edit_text(get_start_spam_text(first_name, user_id, inf["phone"], inf["variable_spam"], int(inf["time"]), True, int(interval_spam)), parse_mode='Markdown', reply_markup=stop_spam_keyboard.as_markup())

        get_spam_status = await start_spam_sms(inf["phone"], int(inf["time"]), inf["variable_spam"], int(user_id), int(interval_spam))

        if get_spam_status == "end":
            await call.message.edit_text(
                get_start_spam_text(first_name, user_id, inf["phone"], inf["variable_spam"], int(inf["time"]),
                                    user_id in check_start, interval_spam), parse_mode='Markdown',
                reply_markup=back_keyboard.as_markup())


    if call.data == "stop_spam":
        inf = await state.get_data()
        if user_id in check_start:
            check_start.remove(user_id)
            await call.message.edit_text(
                get_start_spam_text(first_name, user_id, inf["phone"], inf["variable_spam"], int(inf["time"]),
                                    user_id in check_start, interval_spam), parse_mode='Markdown',
                reply_markup=back_keyboard.as_markup())


async def main():
    dp.startup.register(on_startup)
    dp.shutdown.register(on_shutdown)
    await bot(DeleteWebhook(drop_pending_updates=True))
    await dp.start_polling(bot)

if __name__ == "__main__":

    print(f"start on {datetime.today().strftime('%Y-%m-%d %H:%M:%S')}")
    asyncio.run(main())
