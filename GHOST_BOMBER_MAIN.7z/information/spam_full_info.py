from information.UserAgent import get_agent
from information.Get_Name import get_name
from information.Get_surname import get_surname
from random import choice,randint,sample

#рандомний юзер агент
headers = {
    'User-Agent': get_agent()
}

headers_two = {
    "User-Agent": get_agent(),
    'x-requested-with': 'XMLHttpRequest'
}

#функція для обробки помилки
def Error_request(request, exception):
    print('Error')



#рандомне імя
name = get_name()

#рандомне прізвище
surname = get_surname()

#рандомний пароль
osoboe,chislo,bykva,malenkaya_bykva = list('_-%#@!*&'),list('1234567890'),list('QWERTYUIOPASDFGHJKLZXCVBNM'),list('qwertyuiopasdfghjklzxcvbnm')
password = ([choice(osoboe) for i in range(randint(3,5))]+[choice(bykva) for i in range(randint(2,3))]+[choice(malenkaya_bykva) for i in range(2,3)]+[choice(chislo) for i in range(randint(3,5))])
password = ''.join(sample(password, len(password)))

#реальні пошти
emails_list = ['maksimbardic@gmail.com',
        'ttgbot.proekt@gmail.com',
        'webmine123@gmail.com']

#рандомна пошта
email = ''.join([choice(list('qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM')) for m in range(10)]) + '@gmail.com'
