from aiogram.utils.keyboard import InlineKeyboardBuilder, InlineKeyboardButton

def get_white_list_menu(have_phone: bool):
    white_list = InlineKeyboardBuilder()
    if have_phone:
        white_list.row(InlineKeyboardButton(text="👑 Видалити номер", callback_data="white_list_delete"))
        white_list.row(InlineKeyboardButton(text="👑 Змінити номер", callback_data="white_list_change"))
    else:
        white_list.row(InlineKeyboardButton(text="👑 Додати номер", callback_data="white_list_add"))

    white_list.row(InlineKeyboardButton(text='⬅️ Назад', callback_data="back"))
    return white_list