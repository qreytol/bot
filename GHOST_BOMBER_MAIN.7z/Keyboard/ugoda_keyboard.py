from aiogram.utils.keyboard import InlineKeyboardBuilder, InlineKeyboardButton

ugoda_service_keyboard = InlineKeyboardBuilder()
ugoda_service_keyboard.row(InlineKeyboardButton(text='📃 Користувацька угода', url="https://ghostbomber.space/privacy-policy"))
ugoda_service_keyboard.row(InlineKeyboardButton(text='📃 Політика обробки данних', url="https://ghostbomber.space/terms"))
ugoda_service_keyboard.row(InlineKeyboardButton(text='📃 Публічна оферта', url="https://ghostbomber.space/Offer"))
ugoda_service_keyboard.row(InlineKeyboardButton(text="✔️ Я погоджуюсь", callback_data="accept_ugoda"))