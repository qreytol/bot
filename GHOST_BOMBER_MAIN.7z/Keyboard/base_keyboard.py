from aiogram.utils.keyboard import InlineKeyboardBuilder, InlineKeyboardButton
main_keyboard = InlineKeyboardBuilder()
main_keyboard.row(InlineKeyboardButton(text='🧨 Спам', callback_data="spam"))
main_keyboard.row(InlineKeyboardButton(text='💬 Про сервіс', callback_data="info"))
main_keyboard.row(InlineKeyboardButton(text='☃️ Профіль', callback_data='profile'))