from aiogram.utils.keyboard import InlineKeyboardBuilder, InlineKeyboardButton

def get_intervals(cur_interval: int, cur_rank: int = 1):
    interval_keyboard = InlineKeyboardBuilder()
    if cur_rank == 1:
        c = 0
        for i in range(1, 6):
            if i!=cur_interval:
                if c%2 == 0:
                    interval_keyboard.row(InlineKeyboardButton(text=f'{i} сек', callback_data=f"{i}_set_interval"))
                else:
                    interval_keyboard.add(InlineKeyboardButton(text=f'{i} сек', callback_data=f"{i}_set_interval"))
                c+=1
    interval_keyboard.row(InlineKeyboardButton(text='⬅️ Назад', callback_data="back"))
    return interval_keyboard