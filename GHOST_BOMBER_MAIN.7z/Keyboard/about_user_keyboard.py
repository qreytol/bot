from aiogram.utils.keyboard import InlineKeyboardBuilder, InlineKeyboardButton

user_info_keyboard = InlineKeyboardBuilder()
user_info_keyboard.row(InlineKeyboardButton(text="👑 Змінити ранг", callback_data="change_user_rank"))
user_info_keyboard.row(InlineKeyboardButton(text="💸 Змінити баланс", callback_data="change_user_balance"))
user_info_keyboard.row(InlineKeyboardButton(text='⬅️ Назад', callback_data="back"))