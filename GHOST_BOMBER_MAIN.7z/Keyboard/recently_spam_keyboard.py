from aiogram.utils.keyboard import InlineKeyboardBuilder, InlineKeyboardButton

def get_recently_spam_keyboard(recently: list, current: int):
    recently_spam_keyboard = InlineKeyboardBuilder()

    if current == 1:
        recently_spam_keyboard.add(
            InlineKeyboardButton(text="⏹", callback_data="nichogo")
        )
    else:
        recently_spam_keyboard.add(
            InlineKeyboardButton(text="⬅", callback_data="prev_info")
        )



    recently_spam_keyboard.add(
        InlineKeyboardButton(text=f"[ {current} ]", callback_data="nichogo")
    )


    if current == len(recently):
        recently_spam_keyboard.add(
            InlineKeyboardButton(text=f"⏹", callback_data="nichogo")
        )
    else:
        recently_spam_keyboard.add(
            InlineKeyboardButton(text=f"➡", callback_data="next_info")
        )

    recently_spam_keyboard.row(
        InlineKeyboardButton(text=f"Запустити спам", callback_data="info_start_spam")
    )

    # c = 1
    # for i in recently:
    #     number = i["number"]
    #     recently_spam_keyboard.row(InlineKeyboardButton(text=f"{c}. +{number[:2]} ({number[2:5]}) {number[5:8]}-{number[8:10]}-{number[10:12]}", callback_data=f"spam_info_{c}"))
    #     c+=1



    recently_spam_keyboard.row(InlineKeyboardButton(text='⬅️ Назад', callback_data="back"))
    return recently_spam_keyboard

