from aiogram.utils.keyboard import InlineKeyboardBuilder, InlineKeyboardButton

def get_profile(rank: int):
    profile_keyboard = InlineKeyboardBuilder()
    if rank>=0:
        profile_keyboard.row(InlineKeyboardButton(text='🖊 Білий список', callback_data="white_list_menu"))
        profile_keyboard.row(InlineKeyboardButton(text='🖊 Змінити інтервал', callback_data="change_interval"))
    else:
        profile_keyboard.row(InlineKeyboardButton(text='🖊 Змінити інтервал', callback_data="change_interval"))
    profile_keyboard.row(InlineKeyboardButton(text=' Нещодавні спами', callback_data="recently_spam_list"))
    profile_keyboard.row(InlineKeyboardButton(text='⬅️ Назад', callback_data="back"))
    return profile_keyboard