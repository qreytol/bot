from aiogram.utils.keyboard import InlineKeyboardBuilder, InlineKeyboardButton

about_service_keyboard = InlineKeyboardBuilder()
about_service_keyboard.row(InlineKeyboardButton(text='❓ FAQ', url="https://ghostbomber.space/faq"))
about_service_keyboard.row(InlineKeyboardButton(text='✉️ Чат', url="https://ghostbomber.space/chat"))
about_service_keyboard.row(InlineKeyboardButton(text='👤 Модератор', url="https://ghostbomber.space/moderator"))
about_service_keyboard.row(InlineKeyboardButton(text='⬅️ Назад', callback_data="back"))

