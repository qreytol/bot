from aiogram.utils.keyboard import InlineKeyboardBuilder, InlineKeyboardButton

back_keyboard = InlineKeyboardBuilder()
back_keyboard.add(InlineKeyboardButton(text='⬅️ Назад', callback_data="back"))