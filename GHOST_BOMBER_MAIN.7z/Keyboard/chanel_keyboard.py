from aiogram.utils.keyboard import InlineKeyboardBuilder, InlineKeyboardButton

chanel_keyboard = InlineKeyboardBuilder()
chanel = InlineKeyboardButton(text='Підписатися 😊', url='https://t.me/ghost_bomber_news')
test = InlineKeyboardButton(text='Продовжити ➡️', callback_data='valid')
chanel_keyboard.add(chanel,test)