from aiogram.utils.keyboard import InlineKeyboardBuilder, InlineKeyboardButton

exit_keyboard = InlineKeyboardBuilder()
exit_keyboard.add(InlineKeyboardButton(text='❌ Не інтересно', callback_data="exit_msg"))