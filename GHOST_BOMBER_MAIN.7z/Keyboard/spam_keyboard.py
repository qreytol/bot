from aiogram.utils.keyboard import InlineKeyboardBuilder, InlineKeyboardButton

spam_keyboard = InlineKeyboardBuilder()
nazad = InlineKeyboardButton(text='⬅️ Назад', callback_data="back")
mix = InlineKeyboardButton(text="🤯 Мікс", callback_data='mix')
call = InlineKeyboardButton(text="📞 Звінки", callback_data='call')
sms = InlineKeyboardButton(text="✉️ Смс", callback_data='sms')

spam_keyboard.add(sms,call,mix)
spam_keyboard.row(nazad)

time_spam_keyboard = InlineKeyboardBuilder()
nazad = InlineKeyboardButton(text='⬅️ Назад', callback_data='back')
one_cicles = InlineKeyboardButton(text='1 хв.', callback_data='60')
two_cicles = InlineKeyboardButton(text='2 хв.', callback_data='120')
three_cicles = InlineKeyboardButton(text='3 хв.', callback_data='180')
four_cicles = InlineKeyboardButton(text='4 хв.', callback_data='240')
five_cicles = InlineKeyboardButton(text='5 хв.', callback_data='300')
time_spam_keyboard.add(one_cicles,two_cicles,three_cicles)
time_spam_keyboard.row(four_cicles, five_cicles)
time_spam_keyboard.row(nazad)


stop_spam_keyboard = InlineKeyboardBuilder()
stop_spam = InlineKeyboardButton(text='Зупинити спам ❌', callback_data='stop_spam')
stop_spam_keyboard.add(stop_spam)


def get_type_number_spam_keyboard(recently):
    spam_keyboard = InlineKeyboardBuilder()
    uniq = set(i['number'] for i in recently)
    for i in uniq:
        spam_keyboard.row(InlineKeyboardButton(text=f"+{i[:2]} ({i[2:5]}) {i[5:8]}-{i[8:10]}-{i[10:12]}", callback_data=i))
    spam_keyboard.row(InlineKeyboardButton(text='⬅️ Назад', callback_data="back"))
    return spam_keyboard