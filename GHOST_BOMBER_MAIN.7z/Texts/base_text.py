from random import choice
from datetime import datetime


def get_first_message(name: str, id_user: int) -> str:
    '''Вертає начальне повідомлення'''
    return f'''
👻  Привіт [{name}](tg://user?id={id_user}) {choice(list("💗💖💝💓💞"))}

*Ghost Bomber* ── це бот,через який можна легко відправляти масові смс повідомлення на номера 🇺🇦

*🔧 Функціонал*:
 ┣ Спам СМС 
 ┗ Спам Дзвінками

Перед використанням наших функцій ознайомтесь з [користувацькою угодою](https://ghostbomber.space/privacy-policy), [політикою обробки данних](https://ghostbomber.space/terms) та [публічною офертою](https://ghostbomber.space/Offer).
'''


def spam_text(user_id) -> str:
    '''Вертає текст для типу спама'''
    return f'''
💣 *БОМБЕР* [👻](tg://user?id={user_id})

`Виберіть один варіант для спаму`
'''

def not_subscribe_text(user_id, user_first_name) -> str:
    return f'''
[👻](tg://user?id={user_id}) *{user_first_name} ви не підписані на наш телеграм канал*😣

`Щоб користуватися послугами бота спочатку підпишіться на наш канал та нажміть кнопку "Продовжити"`
'''

def attempt_cheating():
    return '''
Так робити не красиво! 😡

Надіюсь, такого більше не повториться.
'''


def get_user_ugoda():
    return '''
Сервіс є посередником у доставці смс повідомлень і дзвінків через інтернет-ресурси, які перебувають у публічному доступі для фізичних і юридичних осіб, у режимі реального часу; самі дані в процесі передавання на потужностях сервісу не зберігаються і не обробляються.

Запити на отримання смс і дзвінків щодо фізичної особи допустимо виконувати тільки за наявності у Вас письмової згоди на обробку її персональних даних, отримання смс повідомлень і дзвінків. Виконуючи розсилку смс і дзвінків, Ви підтверджуєте наявність такої згоди. Робота сервісу ведеться в рамках Законів України від 1 червня 2010 року, № 2297-VI «Про захист персональних даних», Закону України № 1280-IV «Про телекомунікації» від 18 листопада 2003 року (з поправками), Закону України № 270/96-ВР «Про рекламу» від 3 липня 1996 року; відповідно до яких обробка персональних даних і розсилка здійснюються тільки з згоди суб’єкта персональних даних.

Виконуючи розсилку смс і дзвінків, Ви автоматично підтверджуєте наявність такої згоди і приймаєте користувацьку угоду, політику обробки данних, публічну оферту. Надаючи власної згоди та приймаючи користувацьку угоду, політику обробки данних та публічну оферту нажміть на кнопку "Я погоджуюсь".
'''


def profile_text(user_name: str, user_id: int, white_list: str, money: int, rank: int, date: str, count: str, interval: int) -> str:
    old_date = datetime.strptime(date[:10], "%Y-%m-%d")
    today = datetime.today()
    days_since = (today - old_date).days

    one_text = f'{days_since} дня'
    two_text = f'{days_since} днів'
    three_text = f'{days_since} день'
    get_rank = "Початківець 🌱"
    if rank<=1:
        get_rank = "Початківець 🌱"
    elif rank==2:
        get_rank = "Просунутий 🧑‍💻"
    elif rank==3:
        get_rank = "Майстер 🛠️"
    elif rank==4:
        get_rank = "Експерт 🌟"
    elif rank==5:
        get_rank = "Лідер 👑"


    return f'''
☃️  *Профіль користувача {user_name}* 👻

🗒️ ID: [{str(user_id)}](tg://user?id={user_id})

🗓️ Дата реєстрації: `{date} ({two_text if days_since > 5 or days_since == 0 else three_text if days_since == 1 else one_text})`

💰 Баланс: `{money} грн`
👑 Ранг: `{get_rank}`

⏳ Інтервал між смс: `{interval} {"секунд" if (int(interval)==1 or int(interval)==5) else "секунди"}`

📨 Кількість спамів: `{count}`
'''
#🤍 Білий список: `{'Активований' if white_list else 'Не активований'}`

def info_text(count_users: int, sms_count: int, services_sms_count: int, services_call_count: int) -> str:
    '''Вертає текст з інфомацією про бота'''
    return f'''
💬  *Загальна інформація про бота*  👻

💬 Дата запуску: `10.11.2024 17:14`
💣 Кількість SMS сервісів: `{services_sms_count}`
📞 Кількість CALL сервісів: `{services_call_count}`
👤 Користувачів в боті: `{count_users}`

📱 Номерів заспамлено: `{sms_count}`

*Для співпраці/реклами пишіть модератору.*
'''


def get_first_step_for_sms_spam(user_id) -> str:
    '''Вертає текст про ввід номеру'''
    return f'''
📞  *Введіть номер*  [👻](tg://user?id={user_id})  
 └ Ви можете ввести любий формат номера телефону.

 
❗ `Не забуваємо, що наш бомбер розрахований лише на українські номера.`
'''



def get_spam_time_text(user_id) -> str:
    '''Вертає текст про вибір хвилин'''
    return f'''
[👻](tg://user?id={user_id}) *Виберіть кількість хвилин* ⏳
 └ Або напишіть час в секундах в чат

❗*Максимальна* допустима кількість секунд - 300 (5 хв)
'''


def delay_in_the_seconds(user_id: int, number: str, time: int) -> str:
    '''Вертає текст про затримку між спамом'''
    return f'''
⏳ *Виберіть затримку між сервісами* [👻](tg://user?id={user_id})
 └ `Також ви можете написати свою затримку в секундах`

'''

def get_start_spam_text(first_name: str, user_id: int, number: str, variable_spam: str, time: int, active: bool, interval_sec: int) -> str:
    '''Вертає текст про початок спаму'''
    return f'''
✉️ *{first_name} ви запустили спам* [👻](tg://user?id={user_id})
 ├ *Номер:* `+{number[:2]} ({number[2:5]}) {number[5:8]}-{number[8:10]}-{number[10:12]}` 
 ├ *Спам:* `{"Смс" if variable_spam == 'sms' else 'Дзвінки' if variable_spam == 'call' else 'Мікс'}`
 ├ *Статус:* `{"Почався" if active else "Закінчився"}` 
 ├ *Інтервал:* `{interval_sec} сек.`
 └ *Час спаму:* `{time//60} хвилин {time%60} секунд`
'''


def get_search_text():
    return '''
👻 *Меню пошуку користувача* 

❗ `Введіть в чат айді користувача якого бажаєте знайти`    
'''


def get_search_user_text(username: str, name: str, money: int, rank: int, count: int, date: str, user_id: int):
    old_date = datetime.strptime(date[:10], "%Y-%m-%d")
    today = datetime.today()
    days_since = (today - old_date).days

    one_text = f'{days_since} дня'
    two_text = f'{days_since} днів'
    three_text = f'{days_since} день'


    get_rank = "Початківець 🌱"
    if rank<=1:
        get_rank = "Початківець 🌱"
    elif rank==2:
        get_rank = "Просунутий 🧑‍💻"
    elif rank==3:
        get_rank = "Майстер 🛠️"
    elif rank==4:
        get_rank = "Експерт 🌟"
    elif rank==5:
        get_rank = "Лідер 👑"

    return f'''
👤 Профіль користувача з ID: *{user_id}*

📒 Юзерйнейм: `{username}`
🪪 Ім'я: `{name}`
💸 Баланс: `{money}`
👑 Ранг: `{get_rank}`
📊 Кількість спамів: `{count}`
📅 Зареєстрований: `{date} ({two_text if days_since > 5 or days_since == 0 else three_text if days_since == 1 else one_text} назад)`

'''

def get_change_interval_text(user_id: int, interval: int):
    return f'''
[👻](tg://user?id={user_id}) *Меню зміни інтервалу*

*Інтервал* - `це затримка в секундах між кожним сервісом при спамі.`

*Теперішній інтервал*: `{interval}`

❗ `Виберіть інтервал нажавши на кнопку нижче`
'''


def get_rozsilka_text(user_id: int):
    return f'''
[👻](tg://user?id={user_id}) *Меню розсилки*

❗ `Введіть в чат текст, або надішліть фото. Також фото має бути ординарне`
'''


def current_number_inform(number: str, interval: str, date: str, spam_type: str, time: int, user_id: int):
    return f'''
[👻](tg://user?id={user_id}) *Інформація про спам*

Номер: {number}
інтервал: {interval}
дата: {date}
тип спаму: {spam_type}
тривалість спаму: {time}
'''


# └ *Затримка:* `{(2 if 'normal_spam' in type_spam_sms else 1) + int(full_info["seconds"])} секунди`