from requests import Session
from for_sms_spam.services_for_spam import *

g = Session()

# "380966826804"
#number = "380966826804"
#Danilas_number="380689310909"
number = "380966826804"

def format_phone(number: str, format: str) -> str:
    g = [i for i, k in enumerate(format) if k == '#']
    format = list(format)
    for i in range(len(g)):
        format[g[i]] = number[i]
    return ''.join(format)

# ЧЕКНУТИ ПОТІМ
# 'Sec-Fetch-Dest': 'empty',
# 'Sec-Fetch-Mode': 'cors',
# 'Sec-Fetch-Site': 'same-origin',
# 'Accept': '*/*',
# 'Accept-Language': 'en-US,en;q=0.5',
# 'Accept-Encoding': 'gzip, deflate, br, zstd',

#'X-Requested-With':'XMLHttpRequest'

services = {
    "services": [
        {
            "url": f"https://www.free-hlr.com/",
            "send": "post",
            "headers": {'User-Agent': get_agent()},
            "spam_type": "data",
            "data": {
                'number': f'+{number}',
                'search': ''
            }
        }
    ]
}


for service in services["services"]:
    url = service["url"]
    headers = service["headers"]
    data_type = service["spam_type"]
    data = service["data"]
    send = service["send"]
    if send == "post":
        if data_type == "data":
            res = g.post(url=url, headers=headers,data=data)
        else:
            res = g.post(url=url, headers=headers, json=data)
    else:
        if data_type == "data":
            res = g.get(url=url, headers=headers,data=data)
        else:
            res = g.get(url=url, headers=headers, json=data)
    print(res.text)
    #print(data)

#print(df.text)